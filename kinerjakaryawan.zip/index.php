<?php
session_start();
 

include ('header.php');

		$cari=mysql_query("SELECT * FROM tahunajaran WHERE status='1'");
			$hasil=mysql_num_rows($cari); 
			$ta=mysql_fetch_array($cari);
			if($hasil>1) {
				$namatahun="????/????";
			} else if($hasil==1){
				$namatahun="$ta[nama_tahunajaran]</span>";
				$_SESSION[idtahunajaran]=$ta[id_tahunajaran];
			}
	 

?>

<body>
<div class="container">
<div class="row">

<div class="col-lg-12">
	<img src="images/gogo.png" width="100" style=" float:left; margin:-5px 15px 0px 0px;" class="logo"><h1 class="company" style="color:#20607b;"> Sistem Informasi Kinerja Karyawan <br/><small>SMK CORDOVA MARGOYOSO PATI TAHUN AJARAN <?php echo $namatahun; ?></small> </h1>
</div>

</div>
</div>


<div class="container">
<div class="row">
  <div class="col-lg-12"> 
 
  <nav class="navbar navbar-default" role="navigation" style="background-color:#2c7da0 !important; border-radius:5px; border:1px solid #2c7da0;">
      
        <div class="container-fluid">
          <div class="navbar-header">
 
	  
          </div><!--/.nav-collapse -->
        </div><!--/.container-fluid -->
      </nav>
   <div class="well"> 
     
<div class="col-lg-6">	 
<h2> Login </h2> <hr/>
 
 <?php 
if(isset ($_GET[status]) and $_GET[status]==0)
{
echo " 
<div class='alert alert-danger alert-dismissible' role='alert'>
  <button type='button' class='close' data-dismiss='alert'><span aria-hidden='true'>&times;</span></button>";
			 
				echo "Login Gagal. <br/>Akun tidak memiliki akun, atau salah memasukkan username dan password.<br>";	
			 
		echo "</div>"; 	
}




?>
    	 <form  method="POST" action="cek_login.php" class="form-horizontal" role="form">
		 
	  <div class="form-group">
		<label for="InputUsername" class="col-sm-4 control-label">Username</label>
		<div class="col-sm-8">
		<input type="text" name="user" class="form-control" id="user" placeholder="Usename">
		</div>
	  </div>
	  
	  
	  <div class="form-group" >
		<label for="InputPassword" class="col-sm-4 control-label">Password</label>
		<div class="col-sm-8">
		<input type="password" name="katakunci" class="form-control" id="exampleInputPassword1" placeholder="Password">
		</div>
	  </div>
	
	

	  <div class="form-group">
    <div class="col-sm-offset-4 col-sm-5">
      <button type="submit" class="btn btn-success">Sign in</button>
    </div>
  </div>
	</form>
  
<br /> 

 </div>
 <div class="clearfix"></div>
  </div>

<?php include('footer.php'); ?>


</div><!-- end col-lg-12  -->
</div><!-- end row -->
</div> <!-- end container -->

</body>
</html>
 
