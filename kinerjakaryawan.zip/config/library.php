<?php
//date_default_timezone_set('Asia/Jakarta'); // PHP 6 mengharuskan penyebutan timezone.
$seminggu = array("Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu");
$hari = date("w");
$hari_ini = $seminggu[$hari];

$tgl_sekarang = date("Ymd");
$tgl_skrg     = date("d");
$bln_sekarang = date("m");
$thn_sekarang = date("Y");
$jam_sekarang = date("H:i:s");

$nama_bln=array(1=> "Januari", "Februari", "Maret", "April", "Mei", 
                    "Juni", "Juli", "Agustus", "September", 
                    "Oktober", "November", "Desember");


function buatkan_nomorSI() {

	
	$cariangkaterbesar=mysql_query("select * from shipping_instruction 
	where session_id<>'' order by id_no_si desc limit 0,1");
	$hasil=mysql_fetch_array($cariangkaterbesar);
	$jmlh=mysql_num_rows($cariangkaterbesar);
	$tahun=substr(date("Y"),2,2);
	 
	if ($jmlh>0) {
		$x=substr($hasil[id_no_si],4,3)+1;
		$x= str_pad($x, 3, '0', STR_PAD_LEFT);
		$nomor="SI".$tahun.$x;
		return $nomor;
	} else {
		$nomor="SI".$tahun."001";
		return $nomor;
	}
	
}

function buatkan_kodeTracking() {
 
	$length = 6;
	$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";	
	
	$size = strlen( $chars );
	for( $i = 0; $i < $length; $i++ ) {
		$str .= $chars[ rand( 0, $size - 1 ) ];
	}
	
	return $str;
	 
}


function bulan_romawi($bulan)
{
			switch ($bulan){
					case 1: 
						return "I";
						break;
					case 2:
						return "II";
						break;
					case 3:
						return "III";
						break;
					case 4:
						return "IV";
						break;
					case 5:
						return "V";
						break;
					case 6:
						return "VI";
						break;
					case 7:
						return "VII";
						break;
					case 8:
						return "VIII";
						break;
					case 9:
						return "IX";
						break;
					case 10:
						return "X";
						break;
					case 11:
						return "XI";
						break;
					case 12:
						return "XII";
						break;
				}



}


?>
