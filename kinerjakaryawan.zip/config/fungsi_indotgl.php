<?php
	function tgl_indo($tgl){
			$tanggal = substr($tgl,8,2);
			$bulan = getBulan(substr($tgl,5,2));
			$tahun = substr($tgl,0,4);
			return $tanggal.' '.$bulan.' '.$tahun;		 
	}	

	function getBulan($bln){
				switch ($bln){
					case 1: 
						return "Januari";
						break;
					case 2:
						return "Februari";
						break;
					case 3:
						return "Maret";
						break;
					case 4:
						return "April";
						break;
					case 5:
						return "Mei";
						break;
					case 6:
						return "Juni";
						break;
					case 7:
						return "Juli";
						break;
					case 8:
						return "Agustus";
						break;
					case 9:
						return "September";
						break;
					case 10:
						return "Oktober";
						break;
					case 11:
						return "November";
						break;
					case 12:
						return "Desember";
						break;
				}
			} 
			
			
				function getTanggal($tanggal){
				switch ($tanggal){
					case 1: 
						return "Satu";
						break;
					case 2:
						return "Dua";
						break;
					case 3:
						return "Tiga";
						break;
					case 4:
						return "Empat";
						break;
					case 5:
						return "Lima";
						break;
					case 6:
						return "Enam";
						break;
					case 7:
						return "Tujuh";
						break;
					case 8:
						return "Delapan";
						break;
					case 9:
						return "Sembilan";
						break;
					case 10:
						return "Sepuluh";
						break;
					case 11:
						return "Sebelas";
						break;
					case 12:
						return "Dua belas";
						break;
					case 13: 
						return "Tigas belas";
						break;
					case 14:
						return "Empat belas";
						break;
					case 15:
						return "Lima belas";
						break;
					case 16:
						return "Enam belas";
						break;
					case 17:
						return "Tujuh belas";
						break;
					case 18:
						return "Delapan belas";
						break;
					case 19:
						return "Sembilan belas";
						break;
					case 20:
						return "Dua puluh";
						break;
					case 21:
						return "Dua puluh satu";
						break;
					case 22:
						return "Dua puluh dua";
						break;
					case 23:
						return "Dua puluh tiga";
						break;
					case 24:
						return "Dua puluh empat";
						break;
					case 21:
						return "Dua puluh satu";
						break;
					case 22:
						return "Dua puluh dua";
						break;
					case 23:
						return "Dua puluh tiga";
						break;
					case 24:
						return "Dua puluh empat";
						break;
					case 25:
						return "Dua puluh lima";
						break;
					case 26:
						return "Dua puluh enam";
						break;
					case 27:
						return "Dua puluh tujuh";
						break;
					case 28:
						return "Dua puluh delapan";
						break;
					case 29:
						return "Dua puluh sembilan";
						break;
					case 30:
						return "Tuga puluh";
						break;
					case 31:
						return "Tiga puluh satu";
						break;
					
				}
			} 
			
			
			function getBulan2($bln){
				switch ($bln){
					case 01: 
						return "Januari";
						break;
					case 02:
						return "Februari";
						break;
					case 03:
						return "Maret";
						break;
					case 04:
						return "April";
						break;
					case 05:
						return "Mei";
						break;
					case 06:
						return "Juni";
						break;
					case 07:
						return "Juli";
						break;
					case 08:
						return "Agustus";
						break;
					case 09:
						return "September";
						break;
					case 10:
						return "Oktober";
						break;
					case 11:
						return "November";
						break;
					case 12:
						return "Desember";
						break;
				}
			} 
			
			
	function getTahun($thn){
				switch ($thn){
					case 2015: 
						return "Dua ribu lima belas";
						break;
					case 2016:
						return "Dua ribu enam belas";
						break;
					case 2017:
						return "Dua ribu tujuh belas";
						break;
					case 2018:
						return "Dua ribu delapan belas";
						break;
					case 2019:
						return "Dua ribu sembilan belas";
						break;
					case 2020:
						return "Dua ribu dua puluh";
						break;
					
				}
			} 
			
			
			function getHari($tanggal){	
				$unix = strtotime($tanggal);
				 $hari = date("D", $unix); // hasilnya 3 huruf nama hari bahasa inggris
				 # supaya harinya menjadi bahasa indonesia maka harus kita gant/replace
				 $hari = str_replace('Sun', 'Minggu', $hari);
				 $hari = str_replace('Mon', 'Senin', $hari);
				 $hari = str_replace('Tue', 'Selasa', $hari);
				 $hari = str_replace('Wed', 'Rabu', $hari);
				 $hari = str_replace('Thu', 'Kamis', $hari);
				 $hari = str_replace('Fri', 'Jum\'at', $hari);
				 $hari = str_replace('Sat', 'Sabtu', $hari);
				return $hari;
			}
	
?>
