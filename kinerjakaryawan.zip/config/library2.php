<?php
function buatKode($tabel, $inisial){
	$struktur	= mysql_query("SELECT * FROM $tabel");
	$field		= mysql_field_name($struktur,0);
	$panjang	= mysql_field_len($struktur,0);
	
	// membaca panjang kolom
	$hasil 		= mysql_fetch_field($struktur,0);
	//$panjang	= $hasil->max_length; 
	

 	$qry	= mysql_query("SELECT MAX(".$field.") FROM ".$tabel);
 	$row	= mysql_fetch_array($qry); 
 	if ($row[0]=="") {
 		$angka=0;
	}
 	else {
 		$angka		= substr($row[0], strlen($inisial));
 	}
	
 	$angka++;
 	$angka	=strval($angka); 
 	$tmp	="";
 	for($i=1; $i<=($panjang-strlen($inisial)-strlen($angka)); $i++) {
		$tmp=$tmp."0";	
	}
 	return $inisial.$tmp.$angka;
}

function form_tanggal($nama,$value=''){
echo" <input type='text' name='$nama' id='$nama' size='9' maxlength='20' value='$value' readonly/>&nbsp;
<img src='../images/calendar-add-icon.png' align='top' style='cursor:pointer; margin-top:7px;' alt='kalender'onclick=\"displayCalendar(document.getElementById('$nama'),'dd-mm-yyyy',this)\"/>			
";
}


function InggrisTgl($tanggal){
	$tgl=substr($tanggal,0,2);
	$bln=substr($tanggal,3,2);
	$thn=substr($tanggal,6,4);
	$awal="$thn-$bln-$tgl";
	return $awal;
}

function IndonesiaTgl($tanggal){
	$tgl=substr($tanggal,8,2);
	$bln=substr($tanggal,5,2);
	$thn=substr($tanggal,0,4);
	$awal="$tgl-$bln-$thn";
	return $awal;
}
 
function lastday($month = '', $year = '') {
   if (empty($month)) {
      $month = date('m');
   }
   if (empty($year)) {
      $year = date('Y');
   }
   $result = strtotime("{$year}-{$month}-01");
   $result = strtotime('-1 second', strtotime('+1 month', $result));
   return date('d', $result);
}

function lastmonth($month = '', $year = '') {
   if (empty($month)) {
      $month = date('m');
   }
   if (empty($year)) {
      $year = date('Y');
   }
   $result = strtotime("{$year}-{$month}-01");
   $result = strtotime('-1 second', strtotime('+1 month', $result));
   return date('m', $result);
}

function format_angka($angka) {
	if ($angka > 1) {
		$hasil =  number_format($angka,0, ",",".");
	}
	else {
		$hasil = 0; 
	}
	return $hasil;
}





function createBlankMRP($idpenj, $nopo, $kodebarang) {
	 
 //echo $idpenj." ".$nopo." ".$kodebarang; exit; 
  
 
  $caripo = mysql_query("SELECT * FROM detail_po_konsumen, po_konsumen 
	 			WHERE detail_po_konsumen.id_penjualan=po_konsumen.id_penjualan 
				AND detail_po_konsumen.id_penjualan='$idpenj'");
				
	  while($po=mysql_fetch_array($caripo)){
	  		$jumlahpesanan=$po[jumlah];
	 }		
			
 
	 $id=$kodebarang;
	 $tampil = mysql_query("SELECT * FROM bom
	 			left join barang on barang.kode_barang=bom.kode_barang 
				WHERE bom.kode_barang='$id' AND bom.level='0' ORDER BY bom.level ASC");
	 
	 
    $no = $posisi+1;
    while($r=mysql_fetch_array($tampil)){
		 if($r[tipe]=="barang jadi") {  
				$leadtime=$r[leadtime_produksi];
				$kebutuhannyata=$jumlahpesanan*$r[jml_kebutuhan];
				$scrap = ceil(0.05*$kebutuhannyata); 
				$total = $kebutuhannyata+$scrap;  
		 } 
	    
      	mysql_query("INSERT INTO mrp(no_po, kode_barang, kebutuhan, stok, leadtime, GR, OH, NR, POP, POR) 
						VALUE('$nopo', '$r[kode_barang]', '$total',  '$r[stok]', $leadtime, '', '', '', '', '')");
		
			 $carilevel1 = mysql_query("SELECT * FROM bom 
			 				left join barang on barang.kode_barang=bom.kode_barang 
							WHERE bom.parent='$r[kode_barang]' AND bom.level='1' ORDER BY bom.level ASC");
							
		 	 while($r=mysql_fetch_array($carilevel1)){ 
			 			$kebutuhannyata2=0;
						$scrap2 = 0; 
						$total2 = 0; 
				if($r[tipe]=="bahan baku") { 
						  $leadtime=$r[leadtime_beli];
						  $kebutuhannyata2=$r[jml_kebutuhan]*$total;
						$scrap2 = ceil(0.05*$kebutuhannyata2); 
						$total2 = $kebutuhannyata2+$scrap2; 
						 
				} elseif($r[tipe]=="work in process") {  
						$leadtime=$r[leadtime_produksi];
						$kebutuhannyata2=$r[jml_kebutuhan]*$total;
						$scrap2 = ceil(0.05*$kebutuhannyata2); 
						$total2 = $kebutuhannyata2+$scrap2; 
						 
				} 
				
				
				
				   mysql_query("INSERT INTO mrp(no_po, kode_barang, kebutuhan, stok, leadtime, GR, OH, NR, POP, POR) 
						VALUE('$nopo', '$r[kode_barang]', '$total2', '$r[stok]', $leadtime, '', '', '', '', '')");
					   
					    $carilevel2 = mysql_query("SELECT * FROM bom  
									left join barang on barang.kode_barang=bom.kode_barang 
									WHERE bom.parent='$r[kode_barang]' AND bom.level='2' ORDER BY bom.level ASC");
						 while($r=mysql_fetch_array($carilevel2)){
						 	 		$kebutuhannyata3=0;
									$scrap3 = 0; 
									$total3 = 0; 
							if($r[tipe]=="bahan baku") { 
									$leadtime=$r[leadtime_beli]; 
									$kebutuhannyata3=$r[jml_kebutuhan]*$total2;
									$scrap3 = ceil(0.05*$kebutuhannyata3); 
									$total3 = $kebutuhannyata3+$scrap3; 
							} elseif($r[tipe]=="work in process") {  
									$leadtime=$r[leadtime_produksi]; 
									$kebutuhannyata3=$r[jml_kebutuhan]*$total2;
									$scrap3 = ceil(0.05*$kebutuhannyata3); 
									$total3 = $kebutuhannyata3+$scrap3; 
							}  
							
							  mysql_query("INSERT INTO mrp(no_po, kode_barang, kebutuhan, stok, leadtime, GR, OH, NR, POP, POR) 
						VALUE('$nopo', '$r[kode_barang]', '$total3', '$r[stok]', $leadtime, '', '', '', '', '')");
								   
								   
							     $carilevel3= mysql_query("SELECT * FROM bom WHERE parent='$r[kode_barang]' AND level='3' ORDER BY level ASC");
								 while($r=mysql_fetch_array($carilevel3)){
								  
						 	 
									if($r[tipe]=="bahan baku") { 
											$leadtime=$r[leadtime_beli]; 
									} elseif($r[tipe]=="work in process") {  
											$leadtime=$r[leadtime_produksi]; 
									}  
									
									  mysql_query("INSERT INTO mrp(no_po, kode_barang, stok, leadtime, GR, OH, NR, POP, POR) 
								VALUE('$nopo', '$r[kode_barang]', '$r[stok]', $leadtime, '', '', '', '', '')");
								   
								   
								 }
						}
			}
			   
      
    }
	
	mysql_query("DELETE FROM mrp WHERE kode_barang=''");
    
}









function createMRP($idpenj, $nopo, $kodebarang) {
	 
 //echo $idpenj." ".$nopo." ".$kodebarang; exit; 
  
 
  $caripo = mysql_query("SELECT * FROM detail_po_konsumen, po_konsumen 
	 			WHERE detail_po_konsumen.id_penjualan=po_konsumen.id_penjualan 
				AND detail_po_konsumen.id_penjualan='$idpenj'");
				
	  while($po=mysql_fetch_array($caripo)){
	  		$jumlahpesanan=$po[jumlah];
	 }		
			
 
	 $id=$kodebarang;
	 $tampil = mysql_query("SELECT * FROM bom
	 			left join barang on barang.kode_barang=bom.kode_barang 
				WHERE bom.kode_barang='$id' AND bom.level='0' ORDER BY bom.level ASC");
	 
	 
    while($r=mysql_fetch_array($tampil)){
		 if($r[tipe]=="barang jadi") {  
				$leadtime=$r[leadtime_produksi];
				$kebutuhannyata=$jumlahpesanan*$r[jml_kebutuhan];
				$scrap = ceil(0.05*$kebutuhannyata); 
				$total = $kebutuhannyata+$scrap;  
		 } 
		 
		  $carimrp = mysql_query("SELECT * FROM mrp WHERE no_po='$nopo' AND kode_barang='$r[kode_barang]'");
	      $mrp=mysql_fetch_array($carimrp);
      	 
		  $MPS=array();
		  $GR=array();
		  $SR=array();
		  $OH=array();
		  $NR=array();
		  $POP=array();
		  $POR=array();
		  
		  $MPS=unserialize($mrp[mps]);
		  
		  
		  
		  for ($x=0 ; $x<10 ; $x++) {
		  	if ($MPS[$x]=="") { $MPS[$x]=0; }  
			
			$GR[$x]=$MPS[$x];
			//$SR[$x]=0;
			
			if($mrp[stok]>0 and $GR[$x]<>0) { 
						
						if($mrp[stok]>$GR[$x]) {
							$OH[$x]=$GR[$x]; 
							$mrp[stok]=$mrp[stok]-$GR[$x];
						}else {
							$OH[$x]=$mrp[stok]; 
							$mrp[stok]=0;
						}
					} else { 
						$OH[$x]=0; 
					} 
			
			$NR[$x]=$GR[$x]-$OH[$x];
			$POP[$x]=$NR[$x];
			
			//$POR[$x]=$POP[$x];
			
			 
			array_push($GR,$GR[$x]);
			array_push($SR,$SR[$x]);
			array_push($OH,$OH[$x]);
			array_push($NR,$NR[$x]);
			array_push($POP,$POP[$x]);
			//array_push($POR,$POR[$x]);
		  }
		  
  
		   $grserial=serialize($GR); 
		   $ohserial=serialize($OH);
		   $nrserial=serialize($NR);
		   $popserial=serialize($POP);
		   array_splice($POP, 0, $leadtime); 
		   $porserial=serialize($POP); 
		   
		   mysql_query("UPDATE mrp SET GR='$grserial', OH='$ohserial', NR='$nrserial', POP='$popserial', POR='$porserial' WHERE id_mrp='$mrp[id_mrp]'");
		  // exit;
		 
			 $carilevel1 = mysql_query("SELECT * FROM bom 
			 				left join barang on barang.kode_barang=bom.kode_barang 
							WHERE bom.parent='$r[kode_barang]' AND bom.level='1' ORDER BY bom.level ASC");
							
		 	 while($r=mysql_fetch_array($carilevel1)){ 
			 			$kebutuhannyata2=0;
						$scrap2 = 0; 
						$total2 = 0; 
				if($r[tipe]=="bahan baku") { 
						  $leadtime=$r[leadtime_beli];
						  $kebutuhannyata2=$r[jml_kebutuhan]*$total;
						$scrap2 = ceil(0.05*$kebutuhannyata2); 
						$total2 = $kebutuhannyata2+$scrap2; 
						 
				} elseif($r[tipe]=="work in process") {  
						$leadtime=$r[leadtime_produksi];
						$kebutuhannyata2=$r[jml_kebutuhan]*$total;
						$scrap2 = ceil(0.05*$kebutuhannyata2); 
						$total2 = $kebutuhannyata2+$scrap2; 
						 
				} 
				
				 
				 $carimrp = mysql_query("SELECT * FROM mrp WHERE no_po='$nopo' AND kode_barang='$r[kode_barang]'");
				  $mrp=mysql_fetch_array($carimrp);
				 
				  $MPS=array();
				  $GR=array();
				  $SR=array();
				  $OH=array();
				  $NR=array();
				  $POP=array();
				  $POR=array();
				  
				  $MPS=unserialize($mrp[mps]);
				  
				  
				  
				  for ($x=0 ; $x<10 ; $x++) {
					if ($MPS[$x]=="") { $MPS[$x]=0; }  
					
					$GR[$x]=$MPS[$x];
					 
					
					if($mrp[stok]>0 and $GR[$x]<>0) { 
						
						if($mrp[stok]>$GR[$x]) {
							$OH[$x]=$GR[$x]; 
							$mrp[stok]=$mrp[stok]-$GR[$x];
						}else {
							$OH[$x]=$mrp[stok]; 
							$mrp[stok]=0;
						}
					} else { 
						$OH[$x]=0; 
					} 
					 
					
					$NR[$x]=$GR[$x]-$OH[$x];
					$POP[$x]=$NR[$x];
					
					//$POR[$x]=$POP[$x];
					
					 
					array_push($GR,$GR[$x]);
					array_push($SR,$SR[$x]);
					array_push($OH,$OH[$x]);
					array_push($NR,$NR[$x]);
					array_push($POP,$POP[$x]);
					//array_push($POR,$POR[$x]);
				  }
				  
		  
				   $grserial=serialize($GR); 
				   $ohserial=serialize($OH);
				   $nrserial=serialize($NR);
				   $popserial=serialize($POP);
				   array_splice($POP, 0, $leadtime); 
				   $porserial=serialize($POP); 
				   
				   mysql_query("UPDATE mrp SET GR='$grserial', OH='$ohserial', NR='$nrserial', POP='$popserial', POR='$porserial' WHERE id_mrp='$mrp[id_mrp]'");
		   
					   
					    $carilevel2 = mysql_query("SELECT * FROM bom  
									left join barang on barang.kode_barang=bom.kode_barang 
									WHERE bom.parent='$r[kode_barang]' AND bom.level='2' ORDER BY bom.level ASC");
						 while($r=mysql_fetch_array($carilevel2)){
						 	 		$kebutuhannyata3=0;
									$scrap3 = 0; 
									$total3 = 0; 
							if($r[tipe]=="bahan baku") { 
									$leadtime=$r[leadtime_beli]; 
									$kebutuhannyata3=$r[jml_kebutuhan]*$total2;
									$scrap3 = ceil(0.05*$kebutuhannyata3); 
									$total3 = $kebutuhannyata3+$scrap3; 
							} elseif($r[tipe]=="work in process") {  
									$leadtime=$r[leadtime_produksi]; 
									$kebutuhannyata3=$r[jml_kebutuhan]*$total2;
									$scrap3 = ceil(0.05*$kebutuhannyata3); 
									$total3 = $kebutuhannyata3+$scrap3; 
							}  
							
							  $carimrp = mysql_query("SELECT * FROM mrp WHERE no_po='$nopo' AND kode_barang='$r[kode_barang]'");
							  $mrp=mysql_fetch_array($carimrp);
							 
							  $MPS=array();
							  $GR=array();
							  $SR=array();
							  $OH=array();
							  $NR=array();
							  $POP=array();
							  $POR=array();
							  
							  $MPS=unserialize($mrp[mps]);
							  
							  
							  
							  for ($x=0 ; $x<10 ; $x++) {
								if ($MPS[$x]=="") { $MPS[$x]=0; }  
								
								$GR[$x]=$MPS[$x];
								//$SR[$x]=0;
								
								if($mrp[stok]>0 and $GR[$x]<>0) { 
						
									if($mrp[stok]>$GR[$x]) {
										$OH[$x]=$GR[$x]; 
										$mrp[stok]=$mrp[stok]-$GR[$x];
									}else {
										$OH[$x]=$mrp[stok]; 
										$mrp[stok]=0;
									}
								} else { 
									$OH[$x]=0; 
								} 
								
								$NR[$x]=$GR[$x]-$OH[$x];
								$POP[$x]=$NR[$x];
								
								//$POR[$x]=$POP[$x];
								
								 
								array_push($GR,$GR[$x]);
								array_push($SR,$SR[$x]);
								array_push($OH,$OH[$x]);
								array_push($NR,$NR[$x]);
								array_push($POP,$POP[$x]);
								//array_push($POR,$POR[$x]);
							  }
							  
					  
							   $grserial=serialize($GR); 
							   $ohserial=serialize($OH);
							   $nrserial=serialize($NR);
							   $popserial=serialize($POP);
							   array_splice($POP, 0, $leadtime); 
							   $porserial=serialize($POP); 
							   
							   mysql_query("UPDATE mrp SET GR='$grserial', OH='$ohserial', NR='$nrserial', POP='$popserial', POR='$porserial' WHERE id_mrp='$mrp[id_mrp]'");
								   
								   
								   
							     $carilevel3= mysql_query("SELECT * FROM bom WHERE parent='$r[kode_barang]' AND level='3' ORDER BY level ASC");
								  while($r=mysql_fetch_array($carilevel3)){
						 	 		$kebutuhannyata4=0;
									$scrap4 = 0; 
									$total4 = 0; 
							if($r[tipe]=="bahan baku") { 
									$leadtime=$r[leadtime_beli]; 
									$kebutuhannyata4=$r[jml_kebutuhan]*$total3;
									$scrap4 = ceil(0.05*$kebutuhannyata4); 
									$total4 = $kebutuhannyata4+$scrap4; 
							} elseif($r[tipe]=="work in process") {  
									$leadtime=$r[leadtime_produksi]; 
									$kebutuhannyata4=$r[jml_kebutuhan]*$total3;
									$scrap4 = ceil(0.05*$kebutuhannyata4); 
									$total4 = $kebutuhannyata4+$scrap4; 
							}  
							
							  $carimrp = mysql_query("SELECT * FROM mrp WHERE no_po='$nopo' AND kode_barang='$r[kode_barang]'");
							  $mrp=mysql_fetch_array($carimrp);
							 
							  $MPS=array();
							  $GR=array();
							  $SR=array();
							  $OH=array();
							  $NR=array();
							  $POP=array();
							  $POR=array();
							  
							  $MPS=unserialize($mrp[mps]);
							  
							  
							  
							  for ($x=0 ; $x<10 ; $x++) {
								if ($MPS[$x]=="") { $MPS[$x]=0; }  
								
								$GR[$x]=$MPS[$x];
								//$SR[$x]=0;
								
								if($mrp[stok]>0 and $GR[$x]<>0) { 
						
									if($mrp[stok]>$GR[$x]) {
										$OH[$x]=$GR[$x]; 
										$mrp[stok]=$mrp[stok]-$GR[$x];
									}else {
										$OH[$x]=$mrp[stok]; 
										$mrp[stok]=0;
									}
								} else { 
									$OH[$x]=0; 
								} 
								
								$NR[$x]=$GR[$x]-$OH[$x];
								$POP[$x]=$NR[$x];
								
								//$POR[$x]=$POP[$x];
								
								 
								array_push($GR,$GR[$x]);
								array_push($SR,$SR[$x]);
								array_push($OH,$OH[$x]);
								array_push($NR,$NR[$x]);
								array_push($POP,$POP[$x]);
								//array_push($POR,$POR[$x]);
							  }
							  
					  
							   $grserial=serialize($GR); 
							   $ohserial=serialize($OH);
							   $nrserial=serialize($NR);
							   $popserial=serialize($POP);
							   array_splice($POP, 0, $leadtime); 
							   $porserial=serialize($POP); 
							   
							   mysql_query("UPDATE mrp SET GR='$grserial', OH='$ohserial', NR='$nrserial', POP='$popserial', POR='$porserial' WHERE id_mrp='$mrp[id_mrp]'");
								   
								   
								   
								 }
						}
			}
			   
      
    }
	
	mysql_query("DELETE FROM mrp WHERE kode_barang=''");
    
}

?>