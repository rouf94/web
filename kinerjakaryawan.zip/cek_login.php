<?php
	session_start();
	include "config/koneksi.php";
	$user= $_POST['user'];
	$pass= $_POST['katakunci'];
		$cari = mysql_query("SELECT * FROM pengguna WHERE username='$user' AND password='$pass' AND status='1'");
		$hasil=mysql_num_rows($cari);
		if($hasil>0) 
		{
			$r=mysql_fetch_array($cari);
				  $_SESSION["iduser"]       = $r[id_pengguna];
				  $_SESSION["username"]     = $r[username];
				  $_SESSION["namapengguna"] = $r[nama_lengkap]; 
				  $_SESSION["passuser"]     = $r[password];
				  $_SESSION["level"]     	= $r[level];
				  
				  header("location:admin/dashboard.php?module=home");
		} else
		{		
				
				header ("location:index.php?status=0");
		}
?>