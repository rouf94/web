<?php
session_start();
include "../config/koneksi.php";
include "../config/library.php";
include "../config/class_paging.php";
include "../config/fungsi_seo.php";
include "../config/fungsi_indotgl.php";
include "../config/fungsi_rupiah.php";

$module=$_GET[module];
$act=$_GET[act];

$tglsekarang=date('Y-m-d');

 
/* ========================================================================================================================== */
/* 
/*     PENGGUNA
/*
/* ========================================================================================================================== */

if ($module=='pengguna' AND $act=='input'){


  $insert=mysql_query("INSERT INTO pengguna (username,
                                password, 
								level, 
                                nama_lengkap, 
								jenis_kelamin, 
								alamat_tinggal,
								no_telp,
                                email,
								tgl_buat, 
								status) 
	                       VALUES('$_POST[username]',
                                '$_POST[password]', 
								'$_POST[level]', 
                                '$_POST[nama_pengguna]',
								'$_POST[jk]',
								'$_POST[alamat]',
								'$_POST[notelp]',
                                '$_POST[email]',
								'$tglsekarang',
								'$_POST[status]')");
								
	if ($insert) { 
			$_SESSION[success]="Data pengguna berhasil ditambahkan.";
		} else {
			$_SESSION[danger]="Data pengguna gagal ditambahkan.";
		}							
  header('location:dashboard.php?module='.$module);
}

 
elseif ($module=='pengguna' AND $act=='update'){
  // Apabila password tidak diubah

    $update=mysql_query("UPDATE pengguna SET   username 	='$_POST[username]',
                                password 		='$_POST[password]', 
								level			='$_POST[level]', 
                                nama_lengkap	='$_POST[nama_pengguna]',
								jenis_kelamin	='$_POST[jk]',
								alamat_tinggal	='$_POST[alamat]',
								no_telp			='$_POST[notelp]',
                                email			='$_POST[email]',
								tgl_buat		='$tglsekarang',
								status			='$_POST[status]'
                           WHERE id_pengguna   = '$_POST[id]'");
   if ($update) { 
			$_SESSION[success]="Data pengguna berhasil diupdate.";
		} else {
			$_SESSION[danger]="Data pengguna gagal diupdate.";
		}							
  header('location:dashboard.php?module='.$module);
}


// Update akun
elseif ($module=='editakun' AND $act=='update'){
   
   if ($_POST[password]=="") {
   			$update=mysql_query("UPDATE pengguna SET 
								 username     = '$_POST[username]', 
                                 nama_lengkap = '$_POST[nama_lengkap]',
								 alamat_tinggal 	  = '$_POST[alamat]',
								 jenis_kelamin		  = '$_POST[jk]',
                                 email        = '$_POST[email]',
								 no_telp       = '$_POST[notelp]'  
                           WHERE id_pengguna     = '$_POST[id_admin]'");
   
    } else {

    		$update=mysql_query("UPDATE pengguna SET 
								 username     = '$_POST[username]',
                                 password     = '$_POST[password]',
                                 nama_lengkap = '$_POST[nama_lengkap]',
								 alamat_tinggal 	  = '$_POST[alamat]',
								 jenis_kelamin 		  = '$_POST[jk]',
                                 email        = '$_POST[email]',
								 no_telp       = '$_POST[notelp]'  
                           WHERE id_pengguna     = '$_POST[id_admin]'");
	}
						   
      if ($update) { 
			$_SESSION[success]="Data akun berhasil diupdate.";
		} else {
			$_SESSION[danger]="Data akun gagal diupdate.";
		}							
  header('location:dashboard.php?module=home');
}


/* ========================================================================================================================== */
/* 
/*       TAHUN AJARAN 
/*
/* ========================================================================================================================== */

 

elseif ($module=='tahunajaran' AND $act=='input'){


  $insert=mysql_query("INSERT INTO  tahunajaran (nama_tahunajaran, 
								status) 
	                       VALUES( '$_POST[nama_tahunajaran]', 
								'1')");
	
	
								
	if ($insert) { 
			$_SESSION[success]="Data tahun ajaran berhasil ditambahkan.";
			$cari=mysql_query("SELECT * FROM tahunajaran WHERE status='1'");
			$hasil=mysql_num_rows($cari); 
			if($hasil>1) {
				 $_SESSION[success].="<br/> Non Aktifkan salah satu tahun ajaran karena terdapat dua tahun ajaran aktif.";
			} else if($hasil==1){
				 // do nothing
			}
			
		} else {
			$_SESSION[danger]="Data tahun ajaran gagal ditambahkan.";
		}		
		
							
  header('location:dashboard.php?module='.$module);
}

 
elseif ($module=='tahunajaran' AND $act=='update'){
  // Apabila password tidak diubah

    $update=mysql_query("UPDATE tahunajaran SET   
                                nama_tahunajaran	='$_POST[nama_tahunajaran]', 
								status			    ='$_POST[status]'
                           WHERE id_tahunajaran   = '$_POST[id]'");
   if ($update) { 
			$_SESSION[success]="Data tahun ajaran berhasil diupdate.";
			$cari=mysql_query("SELECT * FROM tahunajaran WHERE status='1'");
			$hasil=mysql_num_rows($cari); 
			if($hasil>1) {
				 $_SESSION[success].="<br/> Non Aktifkan salah satu tahun ajaran karena terdapat dua tahun ajaran aktif.";
			} else if($hasil==1){
				 // do nothing
			}
		} else {
			$_SESSION[danger]="Data tahun ajaran gagal diupdate.";
		}							
  header('location:dashboard.php?module='.$module);
}


elseif ($module=='tahunajaran' AND $act=='hapus'){
 
	
	$hapus = mysql_query("DELETE FROM tahunajaran WHERE id_tahunajaran='$_GET[id]'");
		
	if ($hapus) { 
		$_SESSION[success]="Data tahunajaran berhasil dihapus.";
	} else {
		$_SESSION[danger]="Data tahunajaran gagal dihapus.";
	}
		
  	header('location:dashboard.php?module='.$module);
}



/* ========================================================================================================================== */
/* 
/*     GURU DAN KARYAWAN
/*
/* ========================================================================================================================== */

if ($module=='gurudankaryawan' AND $act=='input'){

  $lokasi_file    = $_FILES['fupload']['tmp_name'];
	  $tipe_file      = $_FILES['fupload']['type'];
	  $nama_file      = $_FILES['fupload']['name'];
	  $acak           = rand(000000,999999);
	  $nama_file_unik = $acak.$nama_file; 
	
		$tgl=date("Y-m-d H:i:s");
	  // Apabila ada gambar yang diupload
	  if (!empty($lokasi_file)){
			  // Apabila tipe gambar bukan jpeg akan tampil peringatan
			  if ($tipe_file != "image/jpeg" AND $tipe_file != "image/png"){
				$_SESSION[danger]="Tipe file harus JPEG atau PNG."; 			
	 			 header('location:dashboard.php?module='.$module);	 		  
			  }
			  else{
			  move_uploaded_file($lokasi_file,"../foto/$nama_file_unik");
			  move_uploaded_file($lokasi_file,"modul/laporan/$nama_file_unik");
			  
			  $insert=mysql_query("INSERT INTO gurudankaryawan (jenis,
                                nik, 
								nuptk, 
								jabatan, 
                                nama_lengkap, 
								jenis_kelamin, 
								alamat_tinggal,
								no_telp,
                                email,
								foto, 
								tgl_buat) 
	                       VALUES('$_POST[jenis]',
                                '$_POST[nik]', 
								'$_POST[nuptk]', 
								'$_POST[jabatan]',
                                '$_POST[nama_gurudankaryawan]',
								'$_POST[jk]',
								'$_POST[alamat]',
								'$_POST[notelp]',
                                '$_POST[email]',
								'$nama_file_unik',
								'$tglsekarang' )");
			  }
	 } else {
	 			  $insert=mysql_query("INSERT INTO gurudankaryawan (jenis,
                                nik, 
								nuptk, 
								jabatan, 
                                nama_lengkap, 
								jenis_kelamin, 
								alamat_tinggal,
								no_telp,
                                email, 
								tgl_buat) 
	                       VALUES('$_POST[jenis]',
                                '$_POST[nik]', 
								'$_POST[nuptk]', 
								'$_POST[jabatan]',
                                '$_POST[nama_gurudankaryawan]',
								'$_POST[jk]',
								'$_POST[alamat]',
								'$_POST[notelp]',
                                '$_POST[email]', 
								'$tglsekarang' )");
	 
	 }		  

  
								
	if ($insert) { 
			$_SESSION[success]="Data guru / karyawan berhasil ditambahkan.";
		} else {
			$_SESSION[danger]="Data guru / karyawan gagal ditambahkan.";
		}							
  header('location:dashboard.php?module='.$module);
}



 
elseif ($module=='gurudankaryawan' AND $act=='update'){
  
     $lokasi_file    = $_FILES['fupload']['tmp_name'];
	  $tipe_file      = $_FILES['fupload']['type'];
	  $nama_file      = $_FILES['fupload']['name'];
	  $acak           = rand(000000,999999);
	  $nama_file_unik = $acak.$nama_file; 
	
		$tgl=date("Y-m-d H:i:s");
	  // Apabila ada gambar yang diupload
	  if (!empty($lokasi_file)){
	  
	   // Apabila tipe gambar bukan jpeg akan tampil peringatan
			  if ($tipe_file != "image/jpeg" AND $tipe_file != "image/png"){
				$_SESSION[danger]="Tipe file harus JPEG atau PNG."; 			
	 			 header('location:dashboard.php?module='.$module);	 		  
			  }
			  else{
			  
			  unlink("../foto/$_POST[fotolama]");
			  unlink("modul/laporan/$_POST[fotolama]");
			  move_uploaded_file($lokasi_file,"../foto/$nama_file_unik");
			  move_uploaded_file($lokasi_file,"/modul/laporan/$nama_file_unik");
			  
			  $update=mysql_query("UPDATE gurudankaryawan SET   jenis 	='$_POST[jenis]',
                                nik 		='$_POST[nik]', 
								nuptk			='$_POST[nuptk]',
								jabatan			='$_POST[jabatan]', 
                                nama_lengkap	='$_POST[nama_gurudankaryawan]',
								jenis_kelamin	='$_POST[jk]',
								alamat_tinggal	='$_POST[alamat]',
								no_telp			='$_POST[notelp]',
                                email			='$_POST[email]',
								foto			='$nama_file_unik',
								status			='$_POST[status]' 
                           WHERE id_gurudankaryawan   = '$_POST[id]'");
			  
			  }
	  
	  } else {
	  		 $update=mysql_query("UPDATE gurudankaryawan SET   jenis 	='$_POST[jenis]',
                                nik 		='$_POST[nik]', 
								nuptk			='$_POST[nuptk]', 
								jabatan			='$_POST[jabatan]', 
                                nama_lengkap	='$_POST[nama_gurudankaryawan]',
								jenis_kelamin	='$_POST[jk]',
								alamat_tinggal	='$_POST[alamat]',
								no_telp			='$_POST[notelp]',
                                email			='$_POST[email]', 
								status			='$_POST[status]' 
                           WHERE id_gurudankaryawan   = '$_POST[id]'");
	  
	  }

    
   if ($update) { 
			$_SESSION[success]="Data guru / karyawan berhasil diupdate.";
		} else {
			$_SESSION[danger]="Data guru / karyawan gagal diupdate.";
		}							
  header('location:dashboard.php?module='.$module);
}

elseif ($module=='gurudankaryawan' AND $act=='hapus'){
 
	
	$hapus = mysql_query("DELETE FROM gurudankaryawan WHERE id_gurudankaryawan='$_GET[id]'");
		
	if ($hapus) { 
		$_SESSION[success]="Data guru / karyawan berhasil dihapus.";
	} else {
		$_SESSION[danger]="Data guru / karyawan gagal dihapus.";
	}
		
  	header('location:dashboard.php?module='.$module);
}




/* ========================================================================================================================== */
/* 
/*       NILAI KINERJA
/*
/* ========================================================================================================================== */

 

elseif ($module=='nilaikinerja' AND $act=='input'){


  $insert=mysql_query("INSERT INTO  nilaikinerja(id_tahunajaran, 
  							id_gurudankaryawan,
							nilai_kehadiran,
							nilai_kedisiplinan,
							nilai_pengajaran,
							tglbuat) 
	                       VALUES( '$_SESSION[idtahunajaran]',
						    '$_POST[idgdk]',
						    '$_POST[nilaikehadiran]',
							'$_POST[nilaikedisiplinan]',
							'$_POST[nilaipengajaran]',
							'$tglsekarang')");
	
	
								
	if ($insert) { 
			$_SESSION[success]="Data nilai kineja berhasil ditambahkan.";
			 
			
		} else {
			$_SESSION[danger]="Data nilai kineja gagal ditambahkan.";
		}		
		
							
  header('location:dashboard.php?module='.$module);
}

 
elseif ($module=='nilaikinerja' AND $act=='update'){
 
 
							
    $update=mysql_query("UPDATE nilaikinerja SET   
                                nilai_kehadiran	='$_POST[nilaikehadiran]', 
								nilai_kedisiplinan	    ='$_POST[nilaikedisiplinan]',
								nilai_pengajaran ='$_POST[nilaipengajaran]'
                           WHERE id_nilaikinerja   = '$_POST[id]'");
   if ($update) { 
			$_SESSION[success]="Data nilai kinerja berhasil diupdate.";
			 
		} else {
			$_SESSION[danger]="Data nilai kinerja gagal diupdate.";
		}							
  header('location:dashboard.php?module='.$module);
}


elseif ($module=='nilaikinerja' AND $act=='hapus'){
  
	$hapus = mysql_query("DELETE FROM nilaikinerja WHERE id_nilaikinerja='$_GET[id]'");
		
	if ($hapus) { 
		$_SESSION[success]="Data nilai kinerja berhasil dihapus.";
	} else {
		$_SESSION[danger]="Data nilai kinerja gagal dihapus.";
	}
		
  	header('location:dashboard.php?module='.$module);
}



?>