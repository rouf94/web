<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{

	if(!isset($_POST['cari']) or $_POST[kategori]=="semua") { 
		$level = "semua";
		$judul = "SEMUA KARYAWAN";
		$filterSql="";
		$selectedsemua="selected=selected";
		
	} elseif(isset($_POST['cari'])){ 
		$judul = $_POST[kategori];
		$level = $_POST[kategori];
		if($judul=="umum") { $judul="GURU DAN KARYAWAN"; } else { $judul=$judul; }
		$filterSql=" WHERE jenis='$_POST[kategori]'";
		if($level=="Guru") { $selectedguru="selected=selected"; } 
		elseif($level=="Karyawan") { $selectedkaryawan="selected=selected"; }  
	}


echo "<h2>Laporan Data Karyawan <br/><small> Tahun Ajaran $namatahun </small></h2><hr/>";
 

		  echo " <br/> <form method=POST action='dashboard.php?module=laporankaryawan'>
		  <table >
		  <tr>
		      <td > Laporan per Jenis Karyawan </td> 
			  <td>  
			  <select name=kategori class='form-control col-lg-3' style='margin:5px;' > 
			  <option value='semua' $selectedsemua> Semua </option>
			  <option value='Guru' $selectedguru> Guru / Pendidik </option>
			  <option value='Karyawan' $selectedkaryawan> Karyawan / Non-Pendidik </option>
		 
			</select> 
			  </tr>
			  <tr>
			  <td> &nbsp; </td>
			  <td> <input type=submit  name=cari class='btn btn-success' value=Cari style='margin:5px;'></td>
		  </tr>
		  </table> </form>";
		  
		  ?>	
		   
	  
	<div class="pull-right" style="margin-right:20px;"> <a href="modul/laporan/laporan_karyawan_pdf.php?tipe=<?php echo $level;?>" class="btn btn-danger"  target="_blank"><span class='glyphicon glyphicon-file'></span> PDF</a></div> 
	<div class="clearfix"></div>
 
	<?php

echo  "  <div class='table-responsive'>
		  <table class='datatable table table-striped'>
          <thead>
		  <th>No</th>
		  <th>NIK</th>
		  <th>Nama </th>
		  <th>Jenis</th>
		  <th>NUPTK</th>
		  <th>Alamat</th>
		  <th>No Telp</th>
		  <th>Email</th> 
		  <th>Jabatan</th>
		  <th>Status</th>
		  <th>Aksi</th>
		  </thead>";

    

    $tampil = mysql_query("SELECT * FROM gurudankaryawan $filterSql order by id_gurudankaryawan DESC");
	
    $no=1;
	$total=0;
    while($r=mysql_fetch_array($tampil)){
	
	if($r[status]==1) {
		$status="Aktif";
	} else {
		$status="Non-Aktif";
	}
		 
			echo "<tr>
				<td>$no</td>
				<td>$r[nik]</td> 
				<td>$r[nama_lengkap]</td> 
				<td>$r[jenis]</td>
				<td>$r[nuptk]</td>
				<td>$r[alamat_tinggal]</td>
				<td>$r[no_telp]</td>
				<td>$r[email]</td>  
				<td>$r[jabatan]</td>
				<td>$status</td>
				<td>
				<a href='modul/laporan/laporan_karyawan_tunggal_pdf.php?id=$r[id_gurudankaryawan]' target='_blank' class='btn btn-sm btn-danger'><span class='glyphicon glyphicon-file'></span>PDF</a> 
				</td> </tr>";
			
			$no++;
	
	}
	
	echo "</table></div>";
   
}
?>
