<?php
switch($_GET[act]){
  // Tampil gurudankaryawan
  default:
    echo "<h2>Kelola Guru dan Karyawan</h2> <hr/>
          <a href='?module=gurudankaryawan&act=tambahgurudankaryawan' class='btn btn-success'> <i class='glyphicon glyphicon-plus-sign'></i> Tambah Guru dan Karyawan </a>
         
            <div class='table-responsive'>
		  <table class='datatable table table-striped'>
		  
          <thead><th>no</th>
		  <th>Status</th>
		  <th>Jenis</th>
		  <th>NIK</th><th>NUPTK</th>
		  <th>Nama Lengkap</th>
		  <th>Nomor Telp</th>
		  <th>Alamat</th>
		  <th>Email</th>
		  <th width=100>aksi</th></thead>";

 
    $tampil = mysql_query("SELECT * FROM gurudankaryawan ");
  
    $no = $posisi+1;
    while($r=mysql_fetch_array($tampil)){
	
	 
      echo "<tr><td>$no</td>
               
				<td >";
				if($r[status]=="1")
				{
					echo "<div class='btn btn-sm btn-success' style='padding:4px 10px;'>Aktif</div>";
				} else {
					echo "<div class='btn btn-sm btn-danger' style='padding:4px 10px;'>Non Aktif</div>";
				}
		echo "		</td>
				<td >$r[jenis]</td> 
				<td >$r[nik]</td>
				<td >$r[nuptk]</td>
				<td >$r[nama_lengkap]</td>
				<td >$r[no_telp]</td>
				<td >$r[alamat_tinggal]</td>
				
				 <td >$r[email]</td>
               <td> <a href=?module=gurudankaryawan&act=editgurudankaryawan&id=$r[id_gurudankaryawan]  class='btn btn-warning' title='Edit'><span class='glyphicon glyphicon-edit'></span></a> 
			   
					 
			   
			   </tr>";
			   /* <a href=./aksi.php?module=gurudankaryawan&act=hapus_gurudankaryawan&id=$r[id_gurudankaryawan] \" 
 					onClick=\"return confirm('Apakah Anda benar-benar akan menghapus $r[nama_lengkap]?')\" class='btn btn-danger' title='Hapus'><span class='glyphicon glyphicon-trash'></a> */
      $no++;
    }
	
    echo "</table> </div>";

   
 
    break;
	
	
	

  case "tambahgurudankaryawan":
   
	?>
	
    <h2>Tambah Guru dan Karyawan</h2> <hr/>
    
	<form id="formulir" enctype="multipart/form-data" class="form-horizontal" method="post" action='./aksi.php?module=gurudankaryawan&act=input' role="form"> 
		  
		   
	<div class="form-group" >
		<label for="nip" class="col-sm-3 control-label">Jenis </label>
		<div class="col-sm-4">
		
         <select name="jenis" class="form-control validate[required]">
        	<option value=""> </option>
            <option value="Guru"   >Guru</option>
            <option value="Karyawan"  >Karyawan</option>
        </select>
		</div>
	</div>
	
	<div class="form-group" >
		<label for="nik" class="col-sm-3 control-label">NIK</label>
		<div class="col-sm-4">
		<input type="text" name="nik" class="form-control" id="nik" placeholder="NIK"   >
		</div>
	</div>
	
		<div class="form-group" >
		<label for="nuptk" class="col-sm-3 control-label">NUPTK</label>
		<div class="col-sm-4">
		<input type="text" name="nuptk" class="form-control" id="nuptk" placeholder="NUPTK"   >
		</div>
	</div>
	
		<div class="form-group" >
		<label for="jabatan" class="col-sm-3 control-label">Jabatan</label>
		<div class="col-sm-4">
		<input type="text" name="jabatan" class="form-control" id="jabatan" placeholder="Jabatan"  >
		</div>
	</div>
	
	 
	
	<br />
<br />

	
  	<div class="form-group" >
		<label for="nama_gurudankaryawan" class="col-sm-3 control-label">Nama Guru / Karyawan</label>
		<div class="col-sm-4">
		<input type="text" name="nama_gurudankaryawan" class="form-control validate[required]" id="nama_gurudankaryawan" placeholder="Nama Guru / Karyawan"   >
		</div>
	</div>
    
     
	 
	<div class="form-group" >
		<label for="nip" class="col-sm-3 control-label">Jenis Kelamin</label>
		<div class="col-sm-4">
		
         <select name="jk" class="form-control validate[required]">
        	<option value=""> </option>
            <option value="Laki-laki"   >Laki-laki</option>
            <option value="Perempuan"  >Perempuan</option>
        </select>
		</div>
	</div>
	
	<div class="form-group" >
		<label for="alamat" class="col-sm-3 control-label">Alamat</label>
		<div class="col-sm-4">
		<input type="text" name="alamat" class="form-control" id="alamat" placeholder="Alamat"   >
		</div>
	</div>
	
	<div class="form-group" >
		<label for="notelp" class="col-sm-3 control-label">Nomor Telpon</label>
		<div class="col-sm-4">
		<input type="text" name="notelp" class="form-control" id="notelp" placeholder="Nomor Telpon"  >
		</div>
	</div>
    
    
	
	<div class="form-group" >
		<label for="email" class="col-sm-3 control-label">Email</label>
		<div class="col-sm-4">
		<input type="text" name="email" class="form-control" id="email" placeholder="Email"  >
		</div>
	</div>

 <div class="form-group" >
		<label for="email" class="col-sm-3 control-label">Foto</label>
		<div class="col-sm-4">
		<input type="file" name="fupload"  id="fupload" placeholder="Foto"  >
		</div>
	</div>


	
	<br />
<br />

     

    
	<div class="form-group">
    	<div class="col-sm-offset-3 col-sm-9">
      		<input type="submit" class="btn btn-success" name="simpan" value="Simpan">
			<input type='button' class="btn btn-warning" value='Batal' onclick='self.history.back()' >
    	</div>
  	</div>
	
	
	</form>
	
    
	<?php
    break;  
	
  
 

  case "editgurudankaryawan":
    $edit = mysql_query("SELECT * FROM gurudankaryawan WHERE id_gurudankaryawan='$_GET[id]'");
    $r    = mysql_fetch_array($edit);
	?>
	
    <h2>Edit Guru dan Karyawan</h2> <hr/>
    
	<form id="formulir" enctype="multipart/form-data" class="form-horizontal" method="post" action='./aksi.php?module=gurudankaryawan&act=update' role="form">
          <input type=hidden name=id value='<?php echo $r[id_gurudankaryawan]; ?>'>
		  
		  <div class="form-group" >
		<label for="nip" class="col-sm-3 control-label">Jenis</label>
		<div class="col-sm-4">
		
         <select name="jenis" class="form-control validate[required]">
        	<option value=""> </option>
            <option value="Guru" <?php if ($r[jenis]=="Guru") { echo "selected=selected";} else { echo ""; }  ?> >Guru</option>
            <option value="Karyawan" <?php if ($r[jenis]=="Karyawan") { echo "selected=selected";} else { echo ""; }  ?>>Karyawan</option>
        </select>
		</div>
	</div>


    
	<div class="form-group" >
		<label for="nik" class="col-sm-3 control-label">NIK</label>
		<div class="col-sm-4">
		<input type="text" name="nik" class="form-control" id="nik" placeholder="NIK" value="<?php echo $r[nik]; ?>" >
		</div>
	</div>
	
	<div class="form-group" >
		<label for="nuptk" class="col-sm-3 control-label">NUPTK</label>
		<div class="col-sm-4">
		<input type="text" name="nuptk" class="form-control" id="nuptk" placeholder="NUPTK" value="<?php echo $r[nuptk]; ?>" >
		</div>
	</div>
	
	<div class="form-group" >
		<label for="Jabatan" class="col-sm-3 control-label">Jabatan</label>
		<div class="col-sm-4">
		<input type="text" name="jabatan" class="form-control" id="jabatan" placeholder="Jabatan" value="<?php echo $r[jabatan]; ?>" >
		</div>
	</div>
	
	<br />
<br />

     
	 	
  	<div class="form-group" >
		<label for="nama_gurudankaryawan" class="col-sm-3 control-label">Nama Guru / Karyawan</label>
		<div class="col-sm-4">
		<input type="text" name="nama_gurudankaryawan" class="form-control validate[required]" id="nama_gurudankaryawan" placeholder="Nama gurudankaryawan" value="<?php echo $r[nama_lengkap]; ?>" >
		</div>
	</div>

	 
	<div class="form-group" >
		<label for="nip" class="col-sm-3 control-label">Jenis Kelamin</label>
		<div class="col-sm-4">
		
         <select name="jk" class="form-control validate[required]">
        	<option value=""> </option>
            <option value="Laki-laki" <?php if ($r[jenis_kelamin]=="Laki-laki") { echo "selected=selected";} else { echo ""; }  ?> >Laki-laki</option>
            <option value="Perempuan" <?php if ($r[jenis_kelamin]=="Perempuan") { echo "selected=selected";} else { echo ""; }  ?>>Perempuan</option>
        </select>
		</div>
	</div>
	
	<div class="form-group" >
		<label for="alamat" class="col-sm-3 control-label">Alamat</label>
		<div class="col-sm-4">
		<input type="text" name="alamat" class="form-control" id="alamat" placeholder="Alamat" value="<?php echo $r[alamat_tinggal]; ?>" >
		</div>
	</div>
	
	<div class="form-group" >
		<label for="notelp" class="col-sm-3 control-label">Nomor Telpon</label>
		<div class="col-sm-4">
		<input type="text" name="notelp" class="form-control" id="notelp" placeholder="Nomor Telpon" value="<?php echo $r[no_telp]; ?>">
		</div>
	</div>
    
    
	
	<div class="form-group" >
		<label for="email" class="col-sm-3 control-label">Email</label>
		<div class="col-sm-4">
		<input type="text" name="email" class="form-control" id="email" placeholder="Email" value="<?php echo $r[email]; ?>">
		</div>
	</div>

	<div class="form-group" >
		<label for="email" class="col-sm-3 control-label">Foto</label>
		<div class="col-sm-4">
		<?php if ($r[foto]!="" or $r[foto]!=NULL  ) { 
				echo "<img src='../foto/$r[foto]' width='200' style='margin-bottom:5px;' >";
		} else { 
				echo "<img src='../foto/noimage.png' width='200' style='margin-bottom:5px;'>";
		} ?>
		<input type="hidden" name="fotolama" class="form-control" id="fotolama" value="<?php echo $r[foto]; ?>">
		<input type="file" name="fupload"  id="fupload" placeholder="Foto"  >
		</div>
	</div>


	
	<br />
<br />
	
	
    	<div class="form-group" >
		<label for="nip" class="col-sm-3 control-label">Status</label>
		<div class="col-sm-4">
		
         <select name="status" class="form-control validate[required]">
        	<option value=""> </option>
            <option value="1" <?php if ($r[status]=="1") { echo "selected=selected";} else { echo ""; }  ?> >Aktif</option>
            <option value="0" <?php if ($r[status]=="0") { echo "selected=selected";} else { echo ""; }  ?>>Non Aktif</option>
        </select>
		</div>
	</div>
    
	<div class="form-group">
    	<div class="col-sm-offset-3 col-sm-9">
      		<input type="submit" class="btn btn-success" name="simpan" value="Simpan">
			<input type='button' class="btn btn-warning" value='Batal' onclick='self.history.back()' >
    	</div>
  	</div>
	
	
	</form>
	
    
	<?php
    break;  
	
	
	

}
?>

