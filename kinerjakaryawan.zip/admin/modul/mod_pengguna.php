<?php
switch($_GET[act]){
  // Tampil pengguna
  default:
    echo "<h2>Kelola Pengguna</h2> <hr/>
          <a href='?module=pengguna&act=tambahpengguna' class='btn btn-success'> <i class='glyphicon glyphicon-plus-sign'></i> Tambah Pengguna </a>
         
            <div class='table-responsive'>
		  <table class='datatable table table-striped'>
		  
          <thead><th>no</th><th>Status</th><th>Username</th><th>Level</th><th>Nama Lengkap</th><th>Nomor Telp</th><th>Alamat</th><th>Email</th><th width=100>aksi</th></thead>";

 
    $tampil = mysql_query("SELECT * FROM pengguna ");
  
    $no = $posisi+1;
    while($r=mysql_fetch_array($tampil)){
	
	if($r[level]=="tu") {$level="Administrasi"; } else { $level="Kepala Sekolah";}
      echo "<tr><td>$no</td>
               
				<td >";
				if($r[status]=="1")
				{
					echo "<div class='btn btn-sm btn-success' style='padding:4px 10px;'>Aktif</div>";
				} else {
					echo "<div class='btn btn-sm btn-danger' style='padding:4px 10px;'>Non Aktif</div>";
				}
		echo "		</td>
				<td >$r[username]</td>
				<td >$level</td>
				<td >$r[nama_lengkap]</td>
				<td >$r[no_telp]</td>
				<td >$r[alamat_tinggal]</td>
				
				 <td >$r[email]</td>
               <td> <a href=?module=pengguna&act=editpengguna&id=$r[id_pengguna]  class='btn btn-warning' title='Edit'><span class='glyphicon glyphicon-edit'></span></a> 
			   
					 
			   
			   </tr>";
			   /* <a href=./aksi.php?module=pengguna&act=hapus_pengguna&id=$r[id_pengguna] \" 
 					onClick=\"return confirm('Apakah Anda benar-benar akan menghapus $r[nama_lengkap]?')\" class='btn btn-danger' title='Hapus'><span class='glyphicon glyphicon-trash'></a> */
      $no++;
    }
	
    echo "</table> </div>";

   
 
    break;
	
	
	

  case "tambahpengguna":
   
	?>
	
    <h2>Tambah Pengguna</h2> <hr/>
    
	<form id="formulir" class="form-horizontal" method="post" action='./aksi.php?module=pengguna&act=input' role="form">
          <input type=hidden name=id value='<?php echo $r[id_pengguna]; ?>'>
		  
  	<div class="form-group" >
		<label for="nama_pengguna" class="col-sm-3 control-label">Nama Pengguna</label>
		<div class="col-sm-4">
		<input type="text" name="nama_pengguna" class="form-control validate[required]" id="nama_pengguna" placeholder="Nama Pengguna"   >
		</div>
	</div>
    
     
	 
	<div class="form-group" >
		<label for="nip" class="col-sm-3 control-label">Jenis Kelamin</label>
		<div class="col-sm-4">
		
         <select name="jk" class="form-control validate[required]">
        	<option value=""> </option>
            <option value="Laki-laki"   >Laki-laki</option>
            <option value="Perempuan"  >Perempuan</option>
        </select>
		</div>
	</div>
	
	<div class="form-group" >
		<label for="alamat" class="col-sm-3 control-label">Alamat</label>
		<div class="col-sm-4">
		<input type="text" name="alamat" class="form-control" id="alamat" placeholder="Alamat"   >
		</div>
	</div>
	
	<div class="form-group" >
		<label for="notelp" class="col-sm-3 control-label">Nomor Telpon</label>
		<div class="col-sm-4">
		<input type="text" name="notelp" class="form-control" id="notelp" placeholder="Nomor Telpon"  >
		</div>
	</div>
    
    
	
	<div class="form-group" >
		<label for="email" class="col-sm-3 control-label">Email</label>
		<div class="col-sm-4">
		<input type="text" name="email" class="form-control" id="email" placeholder="Email"  >
		</div>
	</div>
	<br />
<br />

	
	<div class="form-group" >
		<label for="username" class="col-sm-3 control-label">Username</label>
		<div class="col-sm-4">
		<input type="text" name="username" class="form-control validate[required]" id="username" placeholder="Username"  >
		</div>
	</div>
	
	<div class="form-group" >
		<label for="password" class="col-sm-3 control-label">Password</label>
		<div class="col-sm-4">
		<input type="hidden" name="passwordlama" class="form-control" id="password" placeholder="Password"  >
		<input type="password" name="password" class="form-control  validate[required]" id="password" placeholder="Password"  >
		</div>
	</div>
	
	<br />
<br />

    	<div class="form-group" >
		<label for="nip" class="col-sm-3 control-label">Level</label>
		<div class="col-sm-4">
		
         <select name="level" class="form-control validate[required]">
        	<option value=""> </option>
            <option value="tu" >Administrasi</option>
            <option value="kepsek" ></option> 
        </select>
		</div>
	</div>
	
	
    	<div class="form-group" >
		<label for="nip" class="col-sm-3 control-label">Status</label>
		<div class="col-sm-4">
		
         <select name="status" class="form-control validate[required]">
        	<option value=""> </option>
            <option value="1" >Aktif</option>
            <option value="0"  >Non Aktif</option>
        </select>
		</div>
	</div>
    
	<div class="form-group">
    	<div class="col-sm-offset-3 col-sm-9">
      		<input type="submit" class="btn btn-success" name="simpan" value="Simpan">
			<input type='button' class="btn btn-warning" value='Batal' onclick='self.history.back()' >
    	</div>
  	</div>
	
	
	</form>
	
    
	<?php
    break;  
	
  
 

  case "editpengguna":
    $edit = mysql_query("SELECT * FROM pengguna WHERE id_pengguna='$_GET[id]'");
    $r    = mysql_fetch_array($edit);
	?>
	
    <h2>Edit Pengguna</h2> <hr/>
    
	<form id="formulir" class="form-horizontal" method="post" action='./aksi.php?module=pengguna&act=update' role="form">
          <input type=hidden name=id value='<?php echo $r[id_pengguna]; ?>'>
		  
  	<div class="form-group" >
		<label for="nama_pengguna" class="col-sm-3 control-label">Nama Pengguna</label>
		<div class="col-sm-4">
		<input type="text" name="nama_pengguna" class="form-control validate[required]" id="nama_pengguna" placeholder="Nama Pengguna" value="<?php echo $r[nama_lengkap]; ?>" >
		</div>
	</div>
    
     
	 
	<div class="form-group" >
		<label for="nip" class="col-sm-3 control-label">Jenis Kelamin</label>
		<div class="col-sm-4">
		
         <select name="jk" class="form-control validate[required]">
        	<option value=""> </option>
            <option value="Laki-laki" <?php if ($r[jenis_kelamin]=="Laki-laki") { echo "selected=selected";} else { echo ""; }  ?> >Laki-laki</option>
            <option value="Perempuan" <?php if ($r[jenis_kelamin]=="Perempuan") { echo "selected=selected";} else { echo ""; }  ?>>Perempuan</option>
        </select>
		</div>
	</div>
	
	<div class="form-group" >
		<label for="alamat" class="col-sm-3 control-label">Alamat</label>
		<div class="col-sm-4">
		<input type="text" name="alamat" class="form-control" id="alamat" placeholder="Alamat" value="<?php echo $r[alamat_tinggal]; ?>" >
		</div>
	</div>
	
	<div class="form-group" >
		<label for="notelp" class="col-sm-3 control-label">Nomor Telpon</label>
		<div class="col-sm-4">
		<input type="text" name="notelp" class="form-control" id="notelp" placeholder="Nomor Telpon" value="<?php echo $r[no_telp]; ?>">
		</div>
	</div>
    
    
	
	<div class="form-group" >
		<label for="email" class="col-sm-3 control-label">Email</label>
		<div class="col-sm-4">
		<input type="text" name="email" class="form-control" id="email" placeholder="Email" value="<?php echo $r[email]; ?>">
		</div>
	</div>
	<br />
<br />

	
	<div class="form-group" >
		<label for="username" class="col-sm-3 control-label">Username</label>
		<div class="col-sm-4">
		<input type="hidden" name="username" class="form-control validate[required]" id="username" placeholder="Username" value="<?php echo $r[username]; ?>">
		<input type="text" name="usernamenonaktif" class="form-control validate[required]" id="username" placeholder="Username" value="<?php echo $r[username]; ?>" disabled="disabled">
		</div>
	</div>
	
	<div class="form-group" >
		<label for="password" class="col-sm-3 control-label">Password</label>
		<div class="col-sm-4">
		<input type="hidden" name="passwordlama" class="form-control " id="password" placeholder="Password" value="<?php echo $r[password]; ?>">
		<input type="password" name="password" class="form-control" id="password" placeholder="Password"  >
		</div>
	</div>
	
	<br />
<br />

    	<div class="form-group" >
		<label for="nip" class="col-sm-3 control-label">Level</label>
		<div class="col-sm-4">
		
         <select name="level" class="form-control validate[required]">
        	<option value=""> </option>
            <option value="tu" <?php if ($r[level]=="tu") { echo "selected=selected";} else { echo ""; }  ?> >Administrasi</option>
            <option value="kepsek" <?php if ($r[level]=="kepsek") { echo "selected=selected";} else { echo ""; }  ?>>Kepala Sekolah</option>
			 
        </select>
		</div>
	</div>
	
	
    	<div class="form-group" >
		<label for="nip" class="col-sm-3 control-label">Status</label>
		<div class="col-sm-4">
		
         <select name="status" class="form-control validate[required]">
        	<option value=""> </option>
            <option value="1" <?php if ($r[status]=="1") { echo "selected=selected";} else { echo ""; }  ?> >Aktif</option>
            <option value="0" <?php if ($r[status]=="0") { echo "selected=selected";} else { echo ""; }  ?>>Non Aktif</option>
        </select>
		</div>
	</div>
    
	<div class="form-group">
    	<div class="col-sm-offset-3 col-sm-9">
      		<input type="submit" class="btn btn-success" name="simpan" value="Simpan">
			<input type='button' class="btn btn-warning" value='Batal' onclick='self.history.back()' >
    	</div>
  	</div>
	
	
	</form>
	
    
	<?php
    break;  
	
	
	

}
?>

