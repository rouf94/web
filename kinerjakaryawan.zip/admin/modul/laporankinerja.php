<?php
switch($_GET[act]){
  // Tampil gurudankaryawan
  default:
    echo "<h2>Laporan Kinerja Guru dan Karyawan <br/> <small> Tahun Ajaran $namatahun </small></h2> <hr/>";
    ?>     
    
	<div class="pull-right" style="margin-right:20px;"> <a href="modul/laporan/laporan_kinerja_pdf.php" class="btn btn-danger"  target="_blank"><span class='glyphicon glyphicon-file'></span> PDF</a></div> 
	<div class="clearfix"></div>
 
	
	<?php     
    echo " <div class='table-responsive'>
		  <table class='table table-hovered'>
		  
          <thead><th>no</th>  
		  <th>NIK</th> 
		  <th>Nama Lengkap</th>
		  <th>Jabatan</th>
		  <th>Nilai Kehadiran</th> 
		  <th>Nilai Kedisiplinan</th> 
		  <th>Nilai Pengajaran</th>
		  <th>Rerata</th> 
		  <th>Predikat</th>  
		  </thead>";

 
    $tampil = mysql_query("SELECT gurudankaryawan.*, nilaikinerja.id_tahunajaran FROM gurudankaryawan LEFT JOIN nilaikinerja ON gurudankaryawan.id_gurudankaryawan=nilaikinerja.id_gurudankaryawan WHERE gurudankaryawan.status='1' ");
	
	
  
    $no = $posisi+1;
	$rerata=0;
	$predikat="";
	
    while($r=mysql_fetch_array($tampil)){
 	
	if($r[id_tahunajaran]=="" or $r[id_tahunajaran]==NULL) {
			$statusnilai = "<td> - </td> <td> - </td><td> - </td>";
			 $aksi = "  ";
			 $rerata="-";
			$predikat="-";
			
	} else {
	
	  		$cari = mysql_query("SELECT * FROM nilaikinerja WHERE nilaikinerja.id_gurudankaryawan='$r[id_gurudankaryawan]' AND
	 					nilaikinerja.id_tahunajaran='$_SESSION[idtahunajaran]' ");
     		$nilai=mysql_fetch_array($cari);
	
			$statusnilai = "<td> $nilai[nilai_kehadiran] </td> <td> $nilai[nilai_kedisiplinan] </td> <td> $nilai[nilai_pengajaran] </td>";
			$aksi = "<a href='modul/laporan/laporan_kinerja_perkaryawan_pdf.php?id=$nilai[id_gurudankaryawan]' class='btn btn-sm btn-danger'  target='_blank'><span class='glyphicon glyphicon-file'></span> PDF</a>";
			
			
			if($r[jenis]=="Guru") {
				$rerata = round(($nilai[nilai_kehadiran]+$nilai[nilai_kedisiplinan]+$nilai[nilai_pengajaran])/3);
			} else {
				$rerata = round(($nilai[nilai_kehadiran]+$nilai[nilai_kedisiplinan])/2);
			}
			
			if ($rerata <= 100 and $rerata >= 91) {
				$predikat = "Amat Baik";
				$warna="#FFF";
			} else if ($rerata <= 90 and $rerata >= 76) {
				$predikat = "Baik";
				$warna="#FFF";
			} else if ($rerata <= 75 and $rerata >= 61) {
				$predikat = "Cukup";
				$warna="#FFF";
			} else if ($rerata <= 60 and $rerata >= 51) {
				$predikat = "Sedang";
				$warna="#F9E6E6";
			} else if ($rerata <= 50) {
				$predikat = "Kurang";
				$warna="#F9E6E6";
			}
			
	}
	
	
	
        echo "<tr bgcolor=$warna><td>$no</td> ";
				 
		echo " <td >$r[nik]</td> 
				<td >$r[nama_lengkap]</td>
				<td >$r[jabatan]</td>
			    $statusnilai
				<td> $rerata </td> 
				<td> $predikat </td> 
                  </tr>";
			 
      $no++;
    }
	
    echo "</table> </div>";

   echo '<br/><br/> 
   			<div class=table-responsive>
			<table class=" table tableku table-condensed" width=100% >
			<thead ><th>Nilai</th><th>Predikat</th> <th> Catatan</th> </thead> 
			<tr><td>91 - 100</td><td>Amat Baik</td><td rowspan=5> 
			 
				1. Guru dan karwayan dengan hasil penilian kinerja CUKUP dan SEDANG mendapatkan pembinaan dari Kepala Sekolah <br>
				2. Guru dan karwayan dengan hasil penilian kinerja KURANG mendapatkan pembinaan dari Kepala Sekolah dan Yayasan 
			 
			</td></tr> 
			<tr><td>76 - 90</td><td>Baik</td></tr> 
			<tr><td>61 - 75</td><td>Cukup</td></tr> 
			<tr><td>51 - 60</td><td>Sedang</td></tr> 
			<tr><td>0 - 50 </td><td>Kurang</td></tr> 
			</table></div>
			<br/><br/>';
 
    break;
	
	
	
}
?>

