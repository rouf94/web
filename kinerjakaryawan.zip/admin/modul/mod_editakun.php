<?php
session_start();

switch($_GET[act]){

  default:
  
    $edit=mysql_query("SELECT * FROM pengguna WHERE username='$_SESSION[username]'");
    $r=mysql_fetch_array($edit);
	?>
	
	 <h2>Edit Akun</h2> <hr/>
	 
	 <form id="formulir" class="form-horizontal" method="post" action='./aksi.php?module=editakun&act=update' role="form">
	 <input type=hidden name=id_admin value='<?php echo $r[id_pengguna]; ?>'>
	 
	 
	
	  <div class="form-group" >
		<label for="nama_lengkap" class="col-sm-3 control-label">Nama Lengkap</label>
		<div class="col-sm-4">
		<input type="text" name="nama_lengkap" class="form-control validate[required]" id="nama_lengkap" placeholder="Nama Lengkap" value="<?php echo $r[nama_lengkap];?>">
		</div>
	</div>
	
	 
	<div class="form-group" >
		<label for="nip" class="col-sm-3 control-label">Jenis Kelamin</label>
		<div class="col-sm-4">
		
         <select name="jk" class="form-control validate[required]">
        	<option value=""> </option>
            <option value="Laki-laki" <?php if ($r[jenis_kelamin]=="Laki-laki") { echo "selected=selected";} else { echo ""; }  ?> >Laki-laki</option>
            <option value="Perempuan" <?php if ($r[jenis_kelamin]=="Perempuan") { echo "selected=selected";} else { echo ""; }  ?>>Perempuan</option>
        </select>
		</div>
	</div>
	
	<div class="form-group" >
		<label for="alamat" class="col-sm-3 control-label">Alamat</label>
		<div class="col-sm-4">
		<input type="text" name="alamat" class="form-control" id="alamat" placeholder="Alamat" value="<?php echo $r[alamat_tinggal]; ?>" >
		</div>
	</div>
	
	  <div class="form-group" >
		<label for="notelp" class="col-sm-3 control-label">Nomor Telpon</label>
		<div class="col-sm-4">
		<input type="text" name="notelp" class="form-control" id="notelp" placeholder="Nomor Telpon" value="<?php echo $r[no_telp];?>">
		</div>
	</div>
	
	
	<div class="form-group" >
		<label for="email" class="col-sm-3 control-label">Email</label>
		<div class="col-sm-4">
		<input type="text" name="email" class="form-control" id="email" placeholder="Email" value="<?php echo $r[email];?>">
		</div>
	</div>
	
	<br/><br/><br/>
	  <div class="form-group" >
		<label for="username" class="col-sm-3 control-label">Username</label>
		<div class="col-sm-4">
		<input type="hidden" name="username" class="form-control validate[required]" id="username" placeholder="Username" value="<?php echo $r[username];?>">
		<input type="text" name="usernamenonaktif" class="form-control validate[required]" id="username" placeholder="Username" value="<?php echo $r[username];?>" disabled="disabled">
		</div>
	</div>
	
	  <div class="form-group" >
		<label for="password" class="col-sm-3 control-label">Password</label>
		<div class="col-sm-4">
		<input type="hidden" name="passwordlama" class="form-control validate[required]" id="password" placeholder="Password" value="<?php echo $r[password];?>">
		<input type="password" name="password" class="form-control" id="password" >
		</div>
	</div>
	
	<br/><br/>
		<div class="form-group">
    	<div class="col-sm-offset-3 col-sm-9">
      		<input type="submit" class="btn btn-success" value="Update"> 
			<input type='button' class="btn btn-warning" value='Batal' onclick='self.history.back()'>
    	</div>
  	</div>
		</form>
	<?php	
    break;
  
  
}

?>
