<?php
switch($_GET[act]){
  // Tampil tahunajaran
  default:
    echo "<h2>Kelola Tahun Ajaran</h2> <hr/>
          <a href='?module=tahunajaran&act=tambahtahunajaran' class='btn btn-success'> <i class='glyphicon glyphicon-plus-sign'></i> Tambah Tahun Ajaran </a>
         
            <div class='table-responsive'>
		  <table class='datatable table table-striped'>
		  
          <thead><th>no</th><th>Status</th><th>Nama Tahun Ajaran</th><th width=110>aksi</th></thead>";

 
    $tampil = mysql_query("SELECT * FROM tahunajaran ");
  
    $no = $posisi+1;
    while($r=mysql_fetch_array($tampil)){
	
	 		$cari=mysql_query("SELECT * FROM nilaikinerja WHERE id_tahunajaran='$r[id_tahunajaran]'");
			$hasil=mysql_num_rows($cari);
			
			
			if($hasil>0) {
				$hapus="<a href='#' class='btn btn-danger' title='Hapus' onclick='return confirm(\"Tidak dapat dihapus karena berhubungan dengan data lain! \")'><span class='glyphicon glyphicon-trash'></a>";
			} else if($hasil==0){
				$hapus="<a href='./aksi.php?module=tahunajaran&act=hapus&id=$r[id_tahunajaran]' class='btn btn-danger' title='Hapus' onclick='return confirm(\"Apakah Anda Yakin Akan Menghapus Data ini?\")'><span class='glyphicon glyphicon-trash'></a>";
			}
	 
	 
	 
      echo "<tr><td>$no</td>
               
				<td >";
				if($r[status]=="1")
				{
					echo "<div class='btn btn-sm btn-success' style='padding:4px 10px;'>Aktif</div>";
				} else {
					echo "<div class='btn btn-sm btn-danger' style='padding:4px 10px;'>Tidak Aktif</div>";
				}
		echo "		</td>
				<td >$r[nama_tahunajaran]</td>
			 
               <td> <a href=?module=tahunajaran&act=edittahunajaran&id=$r[id_tahunajaran]  class='btn btn-warning' title='Edit'><span class='glyphicon glyphicon-edit'></span></a> $hapus 
			   
			   </tr>";
			   
			   /* <a href=./aksi.php?module=tahunajaran&act=hapus_tahunajaran&id=$r[id_tahunajaran] \" 
 					onClick=\"return confirm('Apakah Anda benar-benar akan menghapus $r[nama_lengkap]?')\" class='btn btn-danger' title='Hapus'><span class='glyphicon glyphicon-trash'></a> */
      $no++;
    }
	
    echo "</table> </div>";

   
 
    break;
	
	
	

  case "tambahtahunajaran":
   
	?>
	
    <h2>Tambah Tahun Ajaran</h2> <hr/>
    
	<form id="formulir" class="form-horizontal" method="post" action='./aksi.php?module=tahunajaran&act=input' role="form">
         
		  
  	<div class="form-group" >
		<label for="nama_tahunajaran" class="col-sm-3 control-label">Nama Tahun Ajaran</label>
		<div class="col-sm-4">
		<input type="text" name="nama_tahunajaran" class="form-control validate[required]" id="nama_tahunajaran" placeholder="Nama Tahun Ajaran"   >
		</div>
	</div>
    
     
	 
    
	<div class="form-group">
    	<div class="col-sm-offset-3 col-sm-9">
      		<input type="submit" class="btn btn-success" name="simpan" value="Simpan">
			<input type='button' class="btn btn-warning" value='Batal' onclick='self.history.back()' >
    	</div>
  	</div>
	
	
	</form>
	
    
	<?php
    break;  
	
  
 

  case "edittahunajaran":
    $edit = mysql_query("SELECT * FROM tahunajaran WHERE id_tahunajaran='$_GET[id]'");
    $r    = mysql_fetch_array($edit);
	?>
	
    <h2>Edit Tahun Ajaran</h2> <hr/>
    
	<form id="formulir" class="form-horizontal" method="post" action='./aksi.php?module=tahunajaran&act=update' role="form">
          <input type=hidden name=id value='<?php echo $r[id_tahunajaran]; ?>'>
		  
  	<div class="form-group" >
		<label for="nama_tahunajaran" class="col-sm-3 control-label">Nama Tahun Ajaran</label>
		<div class="col-sm-4">
		<input type="text" name="nama_tahunajaran" class="form-control validate[required]" id="nama_tahunajaran" placeholder="Nama Tahun Ajaran" value="<?php echo $r[nama_tahunajaran]; ?>" >
		</div>
	</div>
    
     
	
    	<div class="form-group" >
		<label for="nip" class="col-sm-3 control-label">Status</label>
		<div class="col-sm-4">
		
         <select name="status" class="form-control validate[required]">
        	<option value=""> </option>
            <option value="1" <?php if ($r[status]=="1") { echo "selected=selected";} else { echo ""; }  ?> >Aktif</option>
            <option value="0" <?php if ($r[status]=="0") { echo "selected=selected";} else { echo ""; }  ?>>Non Aktif</option>
        </select>
		</div>
	</div>
    
	<div class="form-group">
    	<div class="col-sm-offset-3 col-sm-9">
      		<input type="submit" class="btn btn-success" name="simpan" value="Simpan">
			<input type='button' class="btn btn-warning" value='Batal' onclick='self.history.back()' >
    	</div>
  	</div>
	
	
	</form>
	
    
	<?php
    break;  
	
	
	

}
?>

