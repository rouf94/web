<?php
switch($_GET[act]){
  // Tampil gurudankaryawan
  default:
    echo "<h2>Penilaian Kinerja Guru dan Karyawan <br/> <small> Tahun Ajaran $namatahun </small></h2> <hr/>
         
         
            <div class='table-responsive'>
		  <table class='datatable table table-striped'>
		  
          <thead><th>no</th>
		  <th>Status</th>
		  <th>Jenis</th>
		  <th>NIK</th>
		  <th>NUPTK</th>
		  <th>Nama Lengkap</th>
		  <th>Jabatan</th>
		  <th>Status Penilaian Kinerja</th> 
		  <th width=110>aksi</th></thead>";

 
    $tampil = mysql_query("SELECT gurudankaryawan.*, nilaikinerja.id_tahunajaran FROM gurudankaryawan LEFT JOIN nilaikinerja ON gurudankaryawan.id_gurudankaryawan=nilaikinerja.id_gurudankaryawan WHERE gurudankaryawan.status='1' ");
	
	
  
    $no = $posisi+1;
    while($r=mysql_fetch_array($tampil)){
 	
	if($r[id_tahunajaran]=="" or $r[id_tahunajaran]==NULL) {
			$statusnilai = "<div class='btn btn-sm btn-danger' style='padding:4px 10px;'>Belum Dinilai</div>";
			$aksi = "<a href='?module=nilaikinerja&act=tambahnilaikinerja&idgdk=".$r[id_gurudankaryawan]."' class='btn btn-success' title='Berikan Nilai'> <i class='glyphicon glyphicon-plus-sign'></i> </a>";
			
	} else {
	
	 $cari = mysql_query("SELECT * FROM nilaikinerja WHERE nilaikinerja.id_gurudankaryawan='$r[id_gurudankaryawan]' AND
	 					nilaikinerja.id_tahunajaran='$_SESSION[idtahunajaran]' ");
      $nilai=mysql_fetch_array($cari);
	
			$statusnilai = "<div class='btn btn-sm btn-success' style='padding:4px 10px;'>Sudah Dinilai</div>";
			$aksi = "<a href=?module=nilaikinerja&act=editnilaikinerja&id=".$nilai[id_nilaikinerja]."  class='btn btn-warning' title='Edit'><span class='glyphicon glyphicon-edit'></span></a>
			<a href=./aksi.php?module=nilaikinerja&act=hapus&id=$nilai[id_nilaikinerja] \" 
 					onClick=\"return confirm('Apakah Anda benar-benar akan menghapus nilai kinerja $r[nama_lengkap]?')\" class='btn btn-danger' title='Hapus'><span class='glyphicon glyphicon-trash'></a>
			";
	}
	
      echo "<tr><td>$no</td>
               
				<td >";
				if($r[status]=="1")
				{
					echo "<div class='btn btn-sm btn-success' style='padding:4px 10px;'>Aktif</div>";
				} else {
					echo "<div class='btn btn-sm btn-danger' style='padding:4px 10px;'>Non Aktif</div>";
				}
		echo "		</td>
				<td >$r[jenis]</td> 
				<td >$r[nik]</td>
				<td >$r[nuptk]</td>
				<td >$r[nama_lengkap]</td>
				<td >$r[jabatan]</td>
			 
				 <td ><center>$statusnilai</center></td>
               <td> $aksi </td>  </tr>";
			 
      $no++;
    }
	
    echo "</table> </div>";

   
 
    break;
	
	
	

  case "tambahnilaikinerja":
   
    $tampil = mysql_query("SELECT * FROM gurudankaryawan WHERE id_gurudankaryawan='$_GET[idgdk]' ");
    $guru=mysql_fetch_array($tampil);
	
	?>
	
    <h2>Tambah Nilai Kinerja </h2> <hr/>
    
	<form id="formulir" enctype="multipart/form-data" class="form-horizontal" method="post" action='./aksi.php?module=nilaikinerja&act=input' role="form">
	<input type="hidden" name="idgdk" value="<?php echo $guru[id_gurudankaryawan];?>" /> 
		  
	<div class="col-lg-4"> 
	<div class="form-group" >
		<label for="nip" class="col-sm-4 control-label">Jenis </label>
		<div class="col-sm-8">
		<input type="text" name="nik" class="form-control" id="nik" placeholder="NIK"  value="<?php echo $guru[jenis]; ?>"  disabled="disabled" >
		</div>
	</div>
	
	<div class="form-group" >
		<label for="nik" class="col-sm-4 control-label">NIK</label>
		<div class="col-sm-8">
		<input type="text" name="nik" class="form-control" id="nik" placeholder="NIK"  value="<?php echo $guru[nik]; ?>"  disabled="disabled" >
		</div>
	</div>
	
		<div class="form-group" >
		<label for="nuptk" class="col-sm-4 control-label">NUPTK</label>
		<div class="col-sm-8">
		<input type="text" name="nuptk" class="form-control" id="nuptk" placeholder="NUPTK"  value="<?php echo $guru[nuptk]; ?>" disabled="disabled" >
		</div>
	</div>
	
		<div class="form-group" >
		<label for="jabatan" class="col-sm-4 control-label">Jabatan</label>
		<div class="col-sm-8">
		<input type="text" name="jabatan" class="form-control" id="jabatan" placeholder="Jabatan" value="<?php echo $guru[jabatan]; ?>" disabled="disabled" >
		</div>
	</div>
		
	</div>
	
	
	
	
	<div class="col-lg-5"> 
	<div class="form-group" >
		<label for="nama_gurudankaryawan" class="col-sm-4 control-label">Nama Lengkap</label>
		<div class="col-sm-8">
		<input type="text" name="nama_gurudankaryawan" class="form-control validate[required]" id="nama_gurudankaryawan" placeholder="Nama Guru / Karyawan"  value="<?php echo $guru[nama_lengkap]; ?>" disabled="disabled" >
		</div>
	</div>
    
     
	 
	<div class="form-group" >
		<label for="nip" class="col-sm-4 control-label">Jenis Kelamin</label>
		<div class="col-sm-8">
		
        <input type="text" name="nama_gurudankaryawan" class="form-control validate[required]" id="nama_gurudankaryawan" placeholder="Nama Guru / Karyawan"  value="<?php echo $guru[jenis_kelamin]; ?>"  disabled="disabled" >
		</div>
	</div>
	
	<div class="form-group" >
		<label for="alamat" class="col-sm-4 control-label">Alamat</label>
		<div class="col-sm-8">
		<input type="text" name="alamat" class="form-control" id="alamat" placeholder="Alamat"  value="<?php echo $guru[alamat_tinggal]; ?>"  disabled="disabled" >
		</div>
	</div>
	
	<div class="form-group" >
		<label for="notelp" class="col-sm-4 control-label">Nomor Telpon</label>
		<div class="col-sm-8">
		<input type="text" name="notelp" class="form-control" id="notelp" placeholder="Nomor Telpon"  value="<?php echo $guru[no_telp]; ?>" disabled="disabled" >
		</div>
	</div>
    
    
	

	
	</div>
 



	
	<div class="col-lg-3"> 
	
	<div class="form-group" >
		<label for="notelp" class="col-sm-4 control-label">Foto</label>
		<div class="col-sm-8">
		 	
	<?php if ($guru[foto]!="" or $guru[foto]!=NULL  ) { 
				echo "<img src='../foto/$guru[foto]' width='100%' style='margin-bottom:5px;' >";
		} else { 
				echo "<img src='../foto/noimage.png' width='100%' style='margin-bottom:5px;'>";
		} ?>
		</div>
	</div>
    

	</div>
	
	
	<div class="col-lg-4"> 
	</div>

	<div class="col-lg-5"> 
			   <br />
<br />
		<div class="form-group" >
		<label for="alamat" class="col-sm-4 control-label">Nilai Kehadiran</label>
		<div class="col-sm-8">
		<input type="text" name="nilaikehadiran" class="form-control" id="nilaikehadiran" placeholder="Nilai Kehadiran"     >
		</div>
	</div>
	
	
		<div class="form-group" >
		<label for="alamat" class="col-sm-4 control-label">Nilai Kedisiplinan</label>
		<div class="col-sm-8">
		<input type="text" name="nilaikedisiplinan" class="form-control" id="nilaikedisiplinan" placeholder="Nilai Kedisiplinan"  >
		</div>
	</div>
	
	
		<div class="form-group" >
		<label for="alamat" class="col-sm-4 control-label">Nilai Pengajaran</label>
		<div class="col-sm-8">
		<input type="text" name="nilaipengajaran" class="form-control" id="nilaipengajaran" placeholder="Nilai Pengajaran"  >
		</div>
	</div>
	
	
		<div class="form-group" >
		<label for="alamat" class="col-sm-4 control-label"> </label>
		<div class="col-sm-8">
		 <input type="submit" class="btn btn-success" name="simpan" value="Simpan">
			<input type='button' class="btn btn-warning" value='Batal' onclick='self.history.back()' >
		</div>
	</div>
	
 
	</div>
  	
 
    <div class="col-lg-2"> 
	</div>
     

    
	<div class="form-group">
    	<div class="col-sm-offset-3 col-sm-9">
      		
    	</div>
  	</div>
	
	
	</form>
	
    
	<?php
    break;  
	
  
 

  case "editnilaikinerja":
    $edit = mysql_query("SELECT * FROM nilaikinerja WHERE id_nilaikinerja='$_GET[id]'");
    $r    = mysql_fetch_array($edit);
	
	$tampil = mysql_query("SELECT * FROM gurudankaryawan WHERE id_gurudankaryawan='$r[id_gurudankaryawan]' ");
    $guru=mysql_fetch_array($tampil);
	
	?>
	
 
		   
		      <h2>Edit Nilai Kinerja </h2> <hr/>
    
	<form id="formulir" enctype="multipart/form-data" class="form-horizontal" method="post" action='./aksi.php?module=nilaikinerja&act=update' role="form">
	<input type="hidden" name="id" value="<?php echo $r[id_nilaikinerja];?>" /> 
		  
	<div class="col-lg-4"> 
	<div class="form-group" >
		<label for="nip" class="col-sm-4 control-label">Jenis </label>
		<div class="col-sm-8">
		<input type="text" name="nik" class="form-control" id="nik" placeholder="NIK"  value="<?php echo $guru[jenis]; ?>"  disabled="disabled" >
		</div>
	</div>
	
	<div class="form-group" >
		<label for="nik" class="col-sm-4 control-label">NIK</label>
		<div class="col-sm-8">
		<input type="text" name="nik" class="form-control" id="nik" placeholder="NIK"  value="<?php echo $guru[nik]; ?>"  disabled="disabled" >
		</div>
	</div>
	
		<div class="form-group" >
		<label for="nuptk" class="col-sm-4 control-label">NUPTK</label>
		<div class="col-sm-8">
		<input type="text" name="nuptk" class="form-control" id="nuptk" placeholder="NUPTK"  value="<?php echo $guru[nuptk]; ?>" disabled="disabled" >
		</div>
	</div>
	
		<div class="form-group" >
		<label for="jabatan" class="col-sm-4 control-label">Jabatan</label>
		<div class="col-sm-8">
		<input type="text" name="jabatan" class="form-control" id="jabatan" placeholder="Jabatan" value="<?php echo $guru[jabatan]; ?>" disabled="disabled" >
		</div>
	</div>
		
	</div>
	
	
	
	
	<div class="col-lg-5"> 
	<div class="form-group" >
		<label for="nama_gurudankaryawan" class="col-sm-4 control-label">Nama Lengkap</label>
		<div class="col-sm-8">
		<input type="text" name="nama_gurudankaryawan" class="form-control validate[required]" id="nama_gurudankaryawan" placeholder="Nama Guru / Karyawan"  value="<?php echo $guru[nama_lengkap]; ?>" disabled="disabled" >
		</div>
	</div>
    
     
	 
	<div class="form-group" >
		<label for="nip" class="col-sm-4 control-label">Jenis Kelamin</label>
		<div class="col-sm-8">
		
        <input type="text" name="nama_gurudankaryawan" class="form-control validate[required]" id="nama_gurudankaryawan" placeholder="Nama Guru / Karyawan"  value="<?php echo $guru[jenis_kelamin]; ?>"  disabled="disabled" >
		</div>
	</div>
	
	<div class="form-group" >
		<label for="alamat" class="col-sm-4 control-label">Alamat</label>
		<div class="col-sm-8">
		<input type="text" name="alamat" class="form-control" id="alamat" placeholder="Alamat"  value="<?php echo $guru[alamat_tinggal]; ?>"  disabled="disabled" >
		</div>
	</div>
	
	<div class="form-group" >
		<label for="notelp" class="col-sm-4 control-label">Nomor Telpon</label>
		<div class="col-sm-8">
		<input type="text" name="notelp" class="form-control" id="notelp" placeholder="Nomor Telpon"  value="<?php echo $guru[no_telp]; ?>" disabled="disabled" >
		</div>
	</div>
    
    
	

	
	</div>
 



	
	<div class="col-lg-3"> 
	
	<div class="form-group" >
		<label for="notelp" class="col-sm-4 control-label">Foto</label>
		<div class="col-sm-8">
		 	
	<?php if ($guru[foto]!="" or $guru[foto]!=NULL  ) { 
				echo "<img src='../foto/$guru[foto]' width='100%' style='margin-bottom:5px;' >";
		} else { 
				echo "<img src='../foto/noimage.png' width='100%' style='margin-bottom:5px;'>";
		} ?>
		</div>
	</div>
    

	</div>
	
	
	<div class="col-lg-4"> 
	</div>

	<div class="col-lg-5"> 
			   <br />
<br />
		<div class="form-group" >
		<label for="alamat" class="col-sm-4 control-label">Nilai Kehadiran</label>
		<div class="col-sm-8">
		<input type="text" name="nilaikehadiran" class="form-control" id="nilaikehadiran" placeholder="Nilai Kehadiran"   value="<?php echo $r[nilai_kehadiran]; ?>"  >
		</div>
	</div>
	
	
		<div class="form-group" >
		<label for="alamat" class="col-sm-4 control-label">Nilai Kedisiplinan</label>
		<div class="col-sm-8">
		<input type="text" name="nilaikedisiplinan" class="form-control" id="nilaikedisiplinan" placeholder="Nilai Kedisiplinan"   value="<?php echo $r[nilai_kedisiplinan]; ?>" >
		</div>
	</div>
	
	
		<div class="form-group" >
		<label for="alamat" class="col-sm-4 control-label">Nilai Pengajaran</label>
		<div class="col-sm-8">
		<input type="text" name="nilaipengajaran" class="form-control" id="nilaipengajaran" placeholder="Nilai Pengajaran"  value="<?php echo $r[nilai_pengajaran]; ?>"  >
		</div>
	</div>
	
	
		<div class="form-group" >
		<label for="alamat" class="col-sm-4 control-label"> </label>
		<div class="col-sm-8">
		 <input type="submit" class="btn btn-success" name="simpan" value="Simpan">
			<input type='button' class="btn btn-warning" value='Batal' onclick='self.history.back()' >
		</div>
	</div>
	
 
	</div>
  	
 
    <div class="col-lg-2"> 
	</div>
     

    
	<div class="form-group">
    	<div class="col-sm-offset-3 col-sm-9">
      		
    	</div>
  	</div>
	
	
	</form>
    
	<?php
    break;  
	
	
	

}
?>

