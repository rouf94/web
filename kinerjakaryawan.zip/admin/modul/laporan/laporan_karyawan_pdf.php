<?php
session_start();
  
include_once "../../../config/koneksi.php"; // Membuka koneksi
include_once "../../../config/fungsi_indotgl.php"; // Membuka koneksi
include_once "../../../config/fungsi_rupiah.php"; // Membuka koneksi
include_once "../../../config/library.php";    // Membuka librari peringah fungsi
  

$tipe 	= isset($_GET['tipe']) ? $_GET['tipe'] : 0;

 
 
 if($tipe=="semua" or $tipe==NULL) { 
		$selectedsemua = "selected=selected" ; 
		$judul=" <h4>YAYASAN CORDOVA </h4> <h3>SMK CORDOVA  </h3> <h6>Jl. Polgarut Selatan, Desa Kajen, Kecamatan Margoyoso, Pati, Jawa Tengah 59154 </h6><hr/> <h5> LAPORAN DATA GURU DAN KARYAWAN </h5>";
	} else { 	
		$filterSql=" WHERE jenis='$_GET[tipe]'";
		if($tipe=="Guru") { 
			$judul= " <h3>YAYASAN CORDOVA </h3> <h4>SMK CORDOVA  </h4> <h6>Jl. Polgarut Selatan, Desa Kajen, Kecamatan Margoyoso, Pati, Jawa Tengah 59154 </h6><hr/> <h5>LAPORAN DATA GURU</h5> "; 
	    } else { 
			$judul= " <h3>YAYASAN CORDOVA </h3> <h4>SMK CORDOVA  </h4> <h6>Jl. Polgarut Selatan, Desa Kajen, Kecamatan Margoyoso, Pati, Jawa Tengah 59154 </h6> <hr/> <br>LAPORAN DATA KARYAWAN"; 
	    }
		
	} 
	


		 
			  
	   $tampil = mysql_query("SELECT * FROM gurudankaryawan $filterSql order by id_gurudankaryawan DESC");
		
	

$xxx='<style>
.tableku {
border-collapse:collapse;
 

}

.tableku td{
border-collapse:collapse;
border:1px solid #666666;
font-size:10px;
padding-left:6px;
padding-right:6px;
}

h3, h4, h5, h6 {
margin:4px;
}

</style>';


    $xxx .= '<div style="margin-left:40px; margin-top:40px; margin-right:30px;"> 
	 <img src="logo.jpg"  align="left" style="margin-bottom:-85pt;">
	<div align=center style="font-size:18pt;">'.$judul.'</div> 
	
    
	 <table class="table tableku table-condensed" width=100%>
	   <tr align="center">
		<td  bgcolor="#CCCCCC" valign=middle ><b>No</b></td>
		<td  bgcolor="#CCCCCC" valign=middle><b>NIK</b></td> 
		<td  bgcolor="#CCCCCC"><b>Nama Lengkap</b></td>
		<td  bgcolor="#CCCCCC"><b>Jabatan</b></td> 
	    <td  bgcolor="#CCCCCC"><strong>Alamat</strong></td>
		<td  bgcolor="#CCCCCC"><strong>No Telp</strong></td>
		<td  bgcolor="#CCCCCC"><b>Email </b></td> 
		<td  bgcolor="#CCCCCC"><b>Status </b></td>
	  </tr>';
	

	  	
	$no=1;
	$total=0;
    while($r=mysql_fetch_array($tampil)){
	 
	 	if($r[status]=='1') { $status="Aktif"; } else { $status="Non Aktif";}
					 
			$xxx .="<tr>
				<td><center>$no</center></td>
				<td>".$r[nik]."</td> 
				<td>".$r[nama_lengkap]."</td> 
				<td>".$r[jabatan]."</td>  
				<td>".$r[alamat_tinggal]."</td> 
				<td>".$r[no_telp]."</td>
				<td>".$r[email]."</td>   
				<td>".$status."</td> </tr>";
			
			$no++;
	
	}
			
		 
			 
     	
			$xxx .= '</table> <br/> <br/><br/>';
			$tgl = tgl_indo(date("Y-m-d"));
			$xxx .= '<div align=right> Pati, '.$tgl.'</div> <br/>';
			$xxx .= '<div align=right> Kepala SMK Cordova</div> <br/> <br/><br/>';
			
			$xxx .= '<div align=right><u>'.$_SESSION[namapengguna].'</u></div>';
			$xxx .= '<div align=right> NIK. </div>';
		
	
    
	
	require_once("dompdf_config.inc.php");

$_GET["save_file"] == false;

$dompdf = new DOMPDF();
$dompdf->set_paper(DEFAULT_PDF_PAPER_SIZE, 'landscape');
$dompdf->load_html($xxx);
$dompdf->render();
$dompdf->stream($judul." ".$tgl.".pdf", array("Attachment" => 0));

?>