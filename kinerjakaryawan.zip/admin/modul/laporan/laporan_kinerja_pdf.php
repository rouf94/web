<?php
session_start();
  
include_once "../../../config/koneksi.php"; // Membuka koneksi
include_once "../../../config/fungsi_indotgl.php"; // Membuka koneksi
include_once "../../../config/fungsi_rupiah.php"; // Membuka koneksi
include_once "../../../config/library.php";    // Membuka librari peringah fungsi
  
 
  
	 
		$judul=" <h4>YAYASAN AL ZAHRA HAJAIN </h4> <h3>SMK CORDOVA  </h3> <h6>Jl. Polgarut Selatan, Desa Kajen, Kecamatan Margoyoso, Pati, Jawa Tengah 59154 </h6><hr/> <h5> LAPORAN KINERJA GURU DAN KARYAWAN </h5>";
	 
 
   $tampil = mysql_query("SELECT gurudankaryawan.*, nilaikinerja.id_tahunajaran FROM gurudankaryawan LEFT JOIN nilaikinerja ON gurudankaryawan.id_gurudankaryawan=nilaikinerja.id_gurudankaryawan WHERE gurudankaryawan.status='1' ");
		
	

$xxx='<style>
.tableku {
border-collapse:collapse;
 

}

.tableku td{
border-collapse:collapse;
border:1px solid #666666;
font-size:10px;
padding-left:6px;
padding-right:6px;
}

h3, h4, h5, h6 {
margin:3px;
}

</style>';


    $xxx .= '<div style="margin-left:40px; margin-top:40px; margin-right:30px;"> 
	 <img src="logo.jpg"  align="left" style="margin-bottom:-85pt;">
	<div align=center style="font-size:18pt;">'.$judul.'</div> 
	
    
	 <table class="table tableku table-condensed" width=100%>
	   <tr align="center">
		<td  bgcolor="#CCCCCC" valign=middle ><b>No</b></td>
		<td  bgcolor="#CCCCCC" valign=middle><b>NIK</b></td> 
		<td  bgcolor="#CCCCCC"><b>Nama Lengkap</b></td>
		<td  bgcolor="#CCCCCC"><b>Jabatan</b></td> 
	    <td  bgcolor="#CCCCCC"><strong>Nilai Kehadiran</strong></td>
		<td  bgcolor="#CCCCCC"><strong>Nilai Kedisiplinan</strong></td>
		<td  bgcolor="#CCCCCC"><strong>Nilai Pengajaran</strong></td>
		<td  bgcolor="#CCCCCC"><b>Rerata </b></td> 
		<td  bgcolor="#CCCCCC"><b>Predikat </b></td>
	  </tr>';
	
	   

	  	
	$no=1;
	
    while($r=mysql_fetch_array($tampil)){
	 
	 		if($r[id_tahunajaran]=="" or $r[id_tahunajaran]==NULL) {
			$statusnilai = "<td><center> - </center></td> <td><center> - </center></td><td><center> - </center></td>";
			 $aksi = "  ";
			 $rerata="-";
			$predikat="-";
			
	} else {
	
	  		$cari = mysql_query("SELECT * FROM nilaikinerja WHERE nilaikinerja.id_gurudankaryawan='$r[id_gurudankaryawan]' AND
	 					nilaikinerja.id_tahunajaran='$_SESSION[idtahunajaran]' ");
     		$nilai=mysql_fetch_array($cari);
	
			$statusnilai = "<td><center>".$nilai[nilai_kehadiran]."<c/enter></td> <td><center>".$nilai[nilai_kedisiplinan]."</center></td> <td><center>".$nilai[nilai_pengajaran]."</center></td>";
			$aksi = "<a href='modul/laporan/laporan_kinerja_perkaryawan_pdf.php?id=$nilai[id_gurudankaryawan]' class='btn btn-sm btn-danger'  target='_blank'><span class='glyphicon glyphicon-file'></span> PDF</a>";
			
			
			if($r[jenis]=="Guru") {
				$rerata = round(($nilai[nilai_kehadiran]+$nilai[nilai_kedisiplinan]+$nilai[nilai_pengajaran])/3);
			} else {
				$rerata = round(($nilai[nilai_kehadiran]+$nilai[nilai_kedisiplinan])/2);
			}
			
			if ($rerata <= 100 and $rerata >= 91) {
				$predikat = "Amat Baik";
				$warna="#FFF";
			} else if ($rerata <= 90 and $rerata >= 76) {
				$predikat = "Baik";
				$warna="#FFF";
			} else if ($rerata <= 75 and $rerata >= 61) {
				$predikat = "Cukup";
				$warna="#FFF";
			} else if ($rerata <= 60 and $rerata >= 51) {
				$predikat = "Sedang";
				$warna="#F9E6E6";
			} else if ($rerata <= 50) {
				$predikat = "Kurang";
				$warna="#F9E6E6";
			}
			
	}			 
			$xxx .="<tr bgcolor=".$warna.">
				<td><center>$no</center></td>
				<td>".$r[nik]."</td> 
				<td>".$r[nama_lengkap]."</td> 
				<td>".$r[jabatan]."</td>  
				$statusnilai  
				<td><center>".$rerata."</center></td> 
				<td><center>".$predikat."</center></td> </tr>";
			
			$no++;
	
	}
			
		 
			 
     	
			$xxx .= '</table> <br/><br/> 
			<table class="tableku" width=100% >
			<tr bgcolor="#CCCCCC"><td>Nilai</td><td>Predikat</td> <td> Catatan</td> </tr> 
			<tr><td>91 - 100</td><td>Amat Baik</td><td rowspan=5> 
			 
				1. Guru dan karwayan dengan hasil penilian kinerja CUKUP dan SEDANG mendapatkan pembinaan dari Kepala Sekolah <br>
				2. Guru dan karwayan dengan hasil penilian kinerja KURANG mendapatkan pembinaan dari Kepala Sekolah dan Yayasan 
			 
			</td></tr> 
			<tr><td>76 - 90</td><td>Baik</td></tr> 
			<tr><td>61 - 75</td><td>Cukup</td></tr> 
			<tr><td>51 - 60</td><td>Sedang</td></tr> 
			<tr><td>0 - 50 </td><td>Kurang</td></tr> 
			</table>
			<br/><br/>';
			$tgl = tgl_indo(date("Y-m-d"));
			$xxx .= '<div align=right> Pati, '.$tgl.'</div> <br/> ';
			$xxx .= '<div align=right> Kepala SMK Cordova</div> <br/> <br/><br/>';
			
			$xxx .= '<div align=right><u>'.$_SESSION[namapengguna].'</u></div>';
			$xxx .= '<div align=right> NIK. 20009182 </div>';
		
	
    
	
	require_once("dompdf_config.inc.php");

$_GET["save_file"] == false;

$dompdf = new DOMPDF();
$dompdf->set_paper(DEFAULT_PDF_PAPER_SIZE, 'landscape');
$dompdf->load_html($xxx);
$dompdf->render();
$dompdf->stream($judul." ".$tgl.".pdf", array("Attachment" => 0));

?>