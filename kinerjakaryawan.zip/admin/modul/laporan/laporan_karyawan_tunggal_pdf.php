<?php
session_start();
  
include_once "../../../config/koneksi.php"; // Membuka koneksi
include_once "../../../config/fungsi_indotgl.php"; // Membuka koneksi
include_once "../../../config/fungsi_rupiah.php"; // Membuka koneksi
include_once "../../../config/library.php";    // Membuka librari peringah fungsi
  

		$id 	= isset($_GET['id']) ? $_GET['id'] : 0;

 
 
 
		$judul= " <h3>YAYASAN CORDOVA </h3> <h4>SMK CORDOVA  </h4> <h6>Jl. Polgarut Selatan  Desa Kajen. <br> Kecamatan Margoyoso. Kabupaten Pati. Jawa Tengah. 59154 </h6> <hr/> <br>DATA KARYAWAN<br><br>"; 
	 


		 
			  
	   $tampil = mysql_query("SELECT * FROM gurudankaryawan WHERE id_gurudankaryawan='$id'");
		
	

$xxx='<style>
.tableku {
border-collapse:collapse;
 

}

.tableku td{
border-collapse:collapse;
border:1px solid #666666;
font-size:10px;
padding-left:6px;
padding-right:6px;
}

h3, h4, h5, h6 {
margin:4px;
}

</style>';
	
	$cari = mysql_query("SELECT * FROM gurudankaryawan WHERE id_gurudankaryawan='$id'");
	while ($k=mysql_fetch_array($cari)) {
		$foto=$k[foto];
	}
	
    $xxx .= '<div style="margin-left:40px; margin-top:40px; margin-right:30px;"> 
	 
	 <img src="logo.jpg"  align="left" style="margin-bottom:-100pt;">
	<div align=center style="font-size:16pt;">'.$judul.'</div> 
	
    
	 <br><br><br/> <br/><br/>
	  
	 <table class="table" width=100%> ';
	

	  	
	$no=1;
	$total=0;
    while($r=mysql_fetch_array($tampil)){
	 
	 	if($r[status]=='1') { $status="Aktif"; } else { $status="Non Aktif";}
					 
			$xxx .="<tr><td>NIK</td><td>: ".$r[nik]."</td> <td rowspan=8 align=right><img src='../../../foto/".$foto."'  style='margin-bottom:0pt; border:1px solid #ccc; padding:2px;  float:right; width:70px; margin-right:20px;'> </td></tr>
			    <tr><td>Nama Lengkap</td><td>: ".$r[nama_lengkap]."</td></tr>
				<tr> <td width=100>Status</td><td>: ".$status."</td> </tr> 
				<tr><td>Jabatan</td><td>: ".$r[jabatan]."</td>  </tr>
				<tr><td> &nbsp; </td><td> &nbsp;  </td> </tr>
				
				<tr><td>Alamat</td><td>: ".$r[alamat_tinggal]."</td> </tr>
				<tr><td>No. Telp</td><td>: ".$r[no_telp]."</td></tr>
				<tr><td>Email</td><td>: ".$r[email]."</td>  </tr> 
				";
			
			$no++;
	
	}
			
		 
			 
     	
			$xxx .= '</table> <br/> <br/><br/><br/> <br/><br/>';
			$tgl = tgl_indo(date("Y-m-d"));
			$xxx .= '<div align=right> Pati, '.$tgl.'</div> <br/>';
			$xxx .= '<div align=right> Kepala SMK Cordova</div> <br/> <br/><br/>';
			
			$xxx .= '<div align=right><u>'.$_SESSION[namapengguna].'</u></div>';
			$xxx .= '<div align=right> NIK. </div>';
		
	
    
	
	require_once("dompdf_config.inc.php");

$_GET["save_file"] == false;

$dompdf = new DOMPDF();
$dompdf->set_paper(DEFAULT_PDF_PAPER_SIZE, 'portrait');
$dompdf->load_html($xxx);
$dompdf->render();
$dompdf->stream($judul." ".$tgl.".pdf", array("Attachment" => 0));

?>