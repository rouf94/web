<?php
switch($_GET[act]){
  // Tampil pengguna
  default:
    echo "<h2>Help</h2> <hr/>";
?>
<style type="text/css">
<!--
.style1 {font-weight: bold}
.style2 {font-weight: bold}
.style3 {font-weight: bold}
-->
</style>
        


<div class="panel-group" id="accordion">
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
          1. Tentang Aplikasi
        </a>
      </h4>
    </div>
    <div id="collapseOne" class="panel-collapse collapse in">
      <div class="panel-body">
        Aplikasi ini dibangun untuk menyimpan dan menghasilkan laporan Kinerja Karyawan SMK CORDOVA MARGOYOSO PATI.      </div>
    </div>
  </div>
  
   <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
         2. Pengguna Aplikasi dan Hak Akses
        </a>
      </h4>
    </div>
    <div id="collapseTwo" class="panel-collapse collapse">
      <div class="panel-body">
        Pengguna Aplikasi :
		  <ol>
		    <li>Bagian Tata Usaha </li>
		    <li>Kepala Sekolah </li> 
        </ol>
	      <p>Bagian Tata Usaha memiliki akses pada menu </p>
	      <ul>
	        <li>mengelola data tahun ajaran</li>
	        <li>mengelola data karyawan</li>
        </ul>
	      <p>Kepala Sekolah memiliki akses pada menu</p>
	     <ul>
	        <li>mengelola data pengguns user </li>
	        <li>mengelola penilaian kinerja karyawan</li>
			<li>melihat laporan kinerja karyawan</li>
        </ul>
      </div>
    </div>
  </div>
  
  
    <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
          3. Tentang Penilaian Kinerja Guru dan Karyawan Sekolah
        </a>
      </h4>
    </div>
    <div id="collapseThree" class="panel-collapse collapse">
      <div class="panel-body">
        
      </div>
    </div>
  </div>
  
  
  

  
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapseEmpat">
          4. Glossary / Kosakata
        </a>
      </h4>
    </div>
    <div id="collapseEmpat" class="panel-collapse collapse">
      <div class="panel-body">
	  	<p>Karyawan Sekolah</p>
        <p>Kinerja Karyawan </p>
		         
      </div>
    </div>
  </div>
</div>
   

<?php 
    break;
 
}
?>

