<?php


// Bagian Home
if ($_GET[module]=='home'){

if($_SESSION[level]=="tu") { $level="Administrasi"; } else { $level="Kepala Sekolah"; } 
  echo "<h3 style='padding-bottom:-3px'>Selamat Datang $_SESSION[namapengguna]</h3>
          <p>Selamat datang di halaman bagian khusus <b> $level </b> <br/> 
		   </p> <br>";

 if($_SESSION[level]=="kepsek") {  
		 echo	"
		
		<div class='col-lg-2 text-center'><a href='?module=pengguna'><IMG src='images/admin.jpg' class='img-circle' style='border: solid 5px #CCC;' width=150 height=150> <br/> Data Pengguna</a>  <br/><br/></div>
		
		 
		
		
		<div class='col-lg-2 text-center'><a href='?module=nilaikinerja'><IMG src='images/kinerja.jpg' class='img-circle' style='border: solid 5px #CCC;' width=150 height=150>  <br/> Penilaian Kinerja</a><br/><br/></div>
		
		<div class='col-lg-2 text-center'><a href='?module=laporankaryawan'><IMG src='images/lapkaryawan.png' class='img-circle' style='border: solid 5px #CCC;' width=150 height=150>  <br/> Laporan Data Karyawan</a><br/><br/></div>
		
		<div class='col-lg-2 text-center'><a href='?module=laporankinerja'><IMG src='images/lapkinerja.png' class='img-circle' style='border: solid 5px #CCC;' width=150 height=150> <br/> Laporan Kinerja Karyawan </a> <br/><br/></div>
		
		<div class='clearfix'></div>
				";
		 
	  
	} else {
	
	 echo	"
		
	 
		
		<div class='col-lg-2 text-center'><a href='?module=tahunajaran'><IMG src='images/calendar.png' class='img-circle' style='border: solid 5px #CCC;' width=150 height=150> <br/> Data Tahun Ajaran</a> <br/><br/></div>
		
		<div class='col-lg-2 text-center'><a href='?module=gurudankaryawan'><IMG src='images/guru.png' class='img-circle' style='border: solid 5px #CCC;' width=150 height=150> <br/> Data Guru dan Karyawan </a> <br/><br/></div>
		
		 
		
		<div class='clearfix'></div>
				";
				
	}  
		
	 


}


elseif ($_GET[module]=='help'){
  include "modul/mod_help.php";
}

elseif ($_GET[module]=='pengguna'){
  include "modul/mod_pengguna.php";
}

elseif ($_GET[module]=='editakun'){
  include "modul/mod_editakun.php";
}

elseif ($_GET[module]=='tahunajaran'){
  include "modul/mod_tahunajaran.php";
}

elseif ($_GET[module]=='gurudankaryawan'){
  include "modul/mod_gurudankaryawan.php";
}

 elseif ($_GET[module]=='nilaikinerja'){
  include "modul/mod_nilaikinerja.php";
}

 elseif ($_GET[module]=='laporankaryawan'){
  include "modul/laporankaryawan.php";
}
 
  elseif ($_GET[module]=='laporankinerja'){
  include "modul/laporankinerja.php";
}

// Apabila modul tidak ditemukan
else{
  echo "<p><b>MODUL BELUM ADA ATAU BELUM LENGKAP</b></p>";
}
?>
