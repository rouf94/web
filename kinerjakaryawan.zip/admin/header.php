<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="icon" type="image/png" href="../images/gogo.png"/>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>SMK CORDOVA MARGOYOSO PATI</title>
<link href="style.css" rel="stylesheet" type="text/css" />

<link href='http://fonts.googleapis.com/css?family=Crete+Round' rel='stylesheet' type='text/css'>


 <script src="../js/jquery.min.js" type="text/javascript" charset="utf-8"></script>
<script src="../js/bootstrap.min.js"></script>
<link href="../css/bootstrap.min.css" rel="stylesheet">

	<link rel="stylesheet" href="../css/datepicker.css">
	 
	<link href="../css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    
    
<!-- TinyMCE -->

		
<script type="text/javascript" src="../tinymce/js/tinymce/tinymce.min.js"></script>
<script type="text/javascript">
tinymce.init({
 menubar : false,
	  forced_root_block : "", 
    force_br_newlines : true,
    force_p_newlines : false,
    selector: "textarea",
	
    plugins: [
        "advlist autolink lists link image charmap print preview anchor",
        "searchreplace visualblocks code fullscreen",
        "insertdatetime media table contextmenu paste  code"
    ],
    toolbar: " styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link | undo redo | jbimages | code"
});
</script>

<style type="text/css">
	th {
		text-transform:uppercase;
		border-bottom:double #999999;
		height:60px;
	}
	
	.table-responsive {
	padding:20px;
	border:none;
	}
	
	.btn-xs {
		padding:5px 5px ;
		 
	}
	
	.dataTables_paginate {
	margin-top:-20px;
	}
	.dataTables_info {
	margin-top:10px;
	}
	.datetimepicker{

	}
	 
	 h1 {
	 font-size:30px !important;
	 }
</style>

<link rel="stylesheet" type="text/css" href="../css/validationEngine.jquery.css" >
 <script src="../js/jquery-1.8.2.min.js" type="text/javascript" charset="utf-8"></script>
<script src="../js/jquery.validationEngine-id.js" type="text/javascript" charset="utf-8"></script>
<script src="../js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>
 

<script>
	$(document).ready(function(){
		$("#formulir").validationEngine();
     });
</script>




 	<link rel="stylesheet" href="css/slider.css" />

 <script src="js/slider.js"></script>

<?php
	include "../config/koneksi.php";
	include "../config/library.php";
	include "../config/library2.php";
	include "../config/fungsi_indotgl.php";
	include "../config/fungsi_combobox.php";
	include "../config/class_paging.php";
	include "../config/fungsi_rupiah.php";
?>


	<script src="../js/jquery.dataTables.min.js"></script>
  
 
 <script src="../js/datatables.js"></script>
		<script type="text/javascript">
		$(document).ready(function() {
			$('.datatable').dataTable({
				"sPaginationType": "bs_normal"
			});	
			$('.datatable').each(function(){
				var datatable = $(this);
				// SEARCH - Add the placeholder for Search and Turn this into in-line form control
				var search_input = datatable.closest('.dataTables_wrapper').find('div[id$=_filter] input');
				search_input.attr('placeholder', 'Search');
				search_input.addClass('form-control input-sm');
				// LENGTH - Inline-Form control
				var length_sel = datatable.closest('.dataTables_wrapper').find('div[id$=_length] select');
				length_sel.addClass('form-control input-sm');
                datatable.bind('page', function(e){
                    window.console && console.log('pagination event:', e) //this event must be fired whenever you paginate
                });
			});
		});
</script>
		
		
<script>
  $(document).ready(function(){
       $(".alert").delay(4000).addClass("in").fadeOut("slow");
    });
</script>

</head>
