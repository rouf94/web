<?php
session_start();

if (empty($_SESSION[username]) AND empty($_SESSION[passuser])){
  header("Location:../index.php");
}
else{

include ('header.php');

			$cari=mysql_query("SELECT * FROM tahunajaran WHERE status='1'");
			$hasil=mysql_num_rows($cari); 
			$ta=mysql_fetch_array($cari);
			if($hasil>1) {
				$namatahun="????/????";
			} else if($hasil==1){
				$namatahun="$ta[nama_tahunajaran]</span>";
				$_SESSION[idtahunajaran]=$ta[id_tahunajaran];
			}
	 
?>

<body>
<div class="container">
<div class="row">


<div class="col-lg-12">
	<img src="../images/gogo.png" width="100" style=" float:left; margin:-5px 15px 0px 0px;" class="logo"><h1 class="company" style="color:#20607b;"> Sistem Informasi Kinerja Karyawan <br/><small>SMK CORDOVA MARGOYOSO PATI TAHUN AJARAN <?php echo $namatahun; ?></small> </h1>
</div>
 

</div>
</div>


<div class="container">
<div class="row">
  <div class="col-lg-12"> 
 

   <?php include("menu_admin.php");	?>
   <div class="well"> 
    <?php include "content.php"; ?>
  </div>

<?php include('footer.php'); ?>


</div><!-- end col-lg-12  -->
</div><!-- end row -->
</div> <!-- end container -->

</body>
</html>
<?php
}
?>


<link href="../css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">

<script src="../css/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="../css/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript" src="../css/bootstrap-datetimepicker.id.js" charset="UTF-8"></script>
	
	<script type="text/javascript">
	
	$(document).ready(function (){
       

    
         $('body').on('focus',".tanggal", function(){                     
                      $(this).datetimepicker({
                            language:  'id',
							format: 'yyyy-mm-dd', 
							weekStart: 1,
							todayBtn:  1,
							autoclose: 1,
							todayHighlight: 1,
							startView: 2,
							minView: 2,
							forceParse: 0
							
                     });
               }); 
		 
		 
		  
	
		
});
		    
	</script>