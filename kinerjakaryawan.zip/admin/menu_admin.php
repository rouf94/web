 
<style type="text/css">
#navbar li a{
	color:#FFF;	
}

#navbar li a:hover{
	color:#CCC;	
}


.dropdown-menu>li
{	position:relative;
	-webkit-user-select: none; /* Chrome/Safari */        
	-moz-user-select: none; /* Firefox */
	-ms-user-select: none; /* IE10+ */
	/* Rules below not implemented in browsers yet */
	-o-user-select: none;
	user-select: none;
	cursor:pointer;
}
.dropdown-menu .sub-menu {
    left: 100%;
    position: absolute;
    top: 0;
    display:none;
    margin-top: -1px;
	border-top-left-radius:0px !important;
	border-bottom-left-radius:0px !important;
	
	box-shadow:none;
}
.right-caret:after,.left-caret:after
 {	content:"";
    border-bottom: 5px solid transparent;
    border-top: 5px solid transparent;
    display: inline-block;
    height: 0;
    vertical-align: middle;
    width: 0;
	margin-left:5px;
}
.right-caret:after
{	border-left: 5px solid #fff;

}
.left-caret:after
{	border-right: 6px solid #fff;
	
}
</style>
     
	  <nav class="navbar navbar-default" role="navigation" style="background-color:#2c7da0 !important; border-radius:5px; border:1px solid #2c7da0;">
      
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="dashboard.php?module=home" >
           <!-- <img src="../images/logo.png" width="40" height="40" style="margin-top:-10px; margin-left:0px;" />  -->
            
            </a>
          </div>
		  
          <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
			
		<li><a href="dashboard.php?module=home"> <i class="glyphicon glyphicon-home"></i> &nbsp;Home</a> </li>	
		
  
		           
        <li class="dropdown" >
	<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="glyphicon glyphicon-list-alt"></i> &nbsp;Master Data <span class="caret"></span></a>
	<ul class="dropdown-menu">
		 <?php if($_SESSION[level]=="kepsek") { ?>
    	 <li><a href="dashboard.php?module=pengguna"><i class="glyphicon glyphicon-lock"></i> &nbsp;Pengguna</a></li> 
		 <?php }		 else {?>
		 <li><a href="dashboard.php?module=tahunajaran"><i class="glyphicon glyphicon-star"></i> &nbsp;Tahun Ajaran </a></li>
		 		 <li><a href="dashboard.php?module=gurudankaryawan"><i class="glyphicon glyphicon-user"></i> &nbsp;Guru dan Karyawan</a></li> 
		 <?php } ?>
	</ul>
</li>

	 
	
	
      <?php if( $_SESSION[level]=="kepsek") { ?>      
        <li class="dropdown" >
	<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="glyphicon glyphicon-cog"></i> &nbsp;Kinerja <span class="caret"></span></a>
	<ul class="dropdown-menu"> 
    <li><a href="dashboard.php?module=nilaikinerja"><i class="glyphicon glyphicon-random"></i> &nbsp;Penilaian Kinerja </a></li> 
		 
	</ul>
</li>
	   <?php } ?>
	  
	  <?php if( $_SESSION[level]=="kepsek") { ?> 
	  
		   <li class="dropdown" >
	<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="glyphicon glyphicon-book"></i> &nbsp;Laporan  <span class="caret"></span></a>
	<ul class="dropdown-menu"> 
	<li><a href="dashboard.php?module=laporankaryawan"><i class="glyphicon glyphicon-book"></i> &nbsp;Laporan Data Karyawan </a></li>
	<li><a href="dashboard.php?module=laporankinerja"><i class="glyphicon glyphicon-book"></i> &nbsp;Laporan Kinerja Karyawan </a></li>
    	
	 
	 	</ul>
</li>
		  <?php } ?>
		 	 
 
		
		 <li><a href="dashboard.php?module=help"> <i class="glyphicon glyphicon-question-sign"></i> &nbsp;Help</a> </li>	
		 
 
				
            </ul>
           
		  <ul class="nav navbar-nav navbar-right">
        <li><a href="#">
        
		 
		</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <i class="glyphicon glyphicon-user"></i> &nbsp;<? echo $_SESSION['namapengguna']; ?> <span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="dashboard.php?module=editakun">Edit Akun</a></li>
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </li>
      </ul>
	 
<br>
	  
          </div><!--/.nav-collapse -->
        </div><!--/.container-fluid -->
      </nav>
      

	  
<script type="text/javascript"> 
$(function(){
	$(".dropdown-menu > li > a.trigger").on("click",function(e){
		var current=$(this).next();
		var grandparent=$(this).parent().parent();
		if($(this).hasClass('left-caret')||$(this).hasClass('right-caret'))
			$(this).toggleClass('right-caret left-caret');
		grandparent.find('.left-caret').not(this).toggleClass('right-caret left-caret');
		grandparent.find(".sub-menu:visible").not(current).hide();
		current.toggle();
		e.stopPropagation();
	});
	$(".dropdown-menu > li > a:not(.trigger)").on("click",function(){
		var root=$(this).closest('.dropdown');
		root.find('.left-caret').toggleClass('right-caret left-caret');
		root.find('.sub-menu:visible').hide();
	});
});


</script>




<?php
if ($_SESSION[success]!=null and $_SESSION[success]!="") { ?>
	<div class="alert alert-success fade in" role="alert">
    <button class="close" data-dismiss="alert" type="button">
    <span aria-hidden="true">�</span>
    <span class="sr-only">Close</span>
    </button>
     <?php echo $_SESSION[success]; ?>
    </div>

<?php	
$_SESSION[success] ="";

} else { }

if ($_SESSION[danger]!=null and $_SESSION[danger]!="") { ?>	
	
  <div class="alert alert-danger fade in" role="alert">
    <button class="close" data-dismiss="alert" type="button">
    <span aria-hidden="true">�</span>
    <span class="sr-only">Close</span>
    </button>
     <?php echo $_SESSION[danger]; ?>
    </div>

<?php	
$_SESSION[danger] =""; 

} else { }

?>