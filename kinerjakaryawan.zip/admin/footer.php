

<nav class="navbar navbar-default" role="navigation" style="background-color:#2c7da0 !important; border-radius:5px; border:1px solid #2c7da0;">
        <div class="container-fluid">
<div  class="navbar-brand col-lg-12" style="color:#FFF; font-size:14px;"> 
<span class="pull-left">
<small> &copy; <?php echo date('Y') ?> SMK CORDOVA MARGOYOSO PATI </small> 
</span>
</div>
		</div>
</nav>



