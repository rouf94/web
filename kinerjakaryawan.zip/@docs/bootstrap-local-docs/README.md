#Bootstrap 3.2.0 Offline Docs

*Up to date with v3.2.0*

Live Demo: http://imagiinate.github.io/bootstrap-local-docs/

##Usage

1. Download the [files](https://github.com/imagiinate/bootstrap-local-docs/archive/master.zip).
2. Extract zip file.
3. Open `index.html` from a browser.


###Note
You can compile the official docs yourself with Jekyll.
